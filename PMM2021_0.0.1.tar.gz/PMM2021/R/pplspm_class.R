#' @title Predidctive PLSPM Model
#' @description
#' \code{pplspm} creates Predidctive PLSPM  Model. \cr
#' \code{is.pplspm()} tests if its argument is a \code{pplspm} .\cr
#' \code{as.pplspm()} attempts to turn a list of \code{cplspm} to a \code{pplspm}.\cr
#' @param x :  a \code{pmm} model.
#' @param  procedure  an optional character indicating the name of a plspm procedure to estimate weights. Possible values are 'laplacian' or 'laplacian' or 'hanafi_wold'
#' @param modes  character vector indicating the estimation mode for each block. Possible values are "A" or "B"
#' @param scheme  string with three possible values "centroid" , "factorial" or 'path'.
#' @return a  \code{pplspm}.
#' @export pplspm
#' @examples
#' data(cheese)
#' path_matrix <- matrix(c(0, 0, 0,1, 0, 0,1, 1, 0),3,3)
#' blocks=list(chim=4:8,rheo=9:10,senso=11:16)
#' x=pmm(cheese, blocks, path_matrix,dim=3)
#' xx=pplspm(x)
pplspm <- function(x, procedure='hanafi_wold',modes=NULL, scheme ="factorial")
{

  # check
  if(!is.pmm(x)) stop("\n'pplspm' x must be  pmm")
  if(!(is.character(scheme) & length(scheme)==1))     stop("\ 'n 'pplspm' scheme must be a string value")
  if(!(scheme=='centroid' |scheme=='factorial'| scheme=='path')) stop("\n'pplspm' scheme invalid value for scheme")

  if(is.null(modes)) modes<-rep("A",length(blocking(x)))
  if(!((is.character(modes) & length(modes)==length(blocking(x))))) stop("\n'pplspm' modes must be an appropriate character vector") # que A ou B
  if(!(all((modes=='B')|(modes=='A')))) stop("\n'pplspm' modes possible values of modes are A or B")
  if(!((is.character(procedure) | length(procedure)!=1)))     stop("\n'pplspm' procedure must be a string")
  if(!(all(procedure=='lohmoller'|procedure=='laplacian'|procedure=='hanafi_wold'))) stop("\'pplspm' invalid name for procedure")

  y=x
  if(any(do.call(rbind,lapply(MVs(y),function(x){is.null(attr(x,"scaled:center"))})))){
   yy<-lapply(MVs(y),function(x){scale(x,scale=FALSE)})
   MVs(y)<-yy
  }
  ww=start(y)
  for (h in 1:length(ww)){
    vv=bvec2diag(ww[[h]],blocking(y))
    d=apply(MVs(y)[[h]]%*%vv,2,'sd')
    dinv=1/d
    dinv[d < .Machine$double.eps]=0
    vv=as.vector(vv%*%diag(dinv)%*%rep(1,length(blocking(y))))
    names(vv)<-colnames(MVs(y)[[h]])
    ww[[h]]<-vv
  }
  start(y)<-ww
  # scaling weights vector

  ww<-weights(y)
  for (h in 1:length(ww)){
    vv=bvec2diag(ww[[h]],blocking(y))
    d=apply(MVs(y)[[h]]%*%vv,2,'sd')
    dinv=1/d
    dinv[d < .Machine$double.eps]=0
    vv=as.vector(vv%*%diag(dinv)%*%rep(1,length(blocking(y))))
    names(vv)<-colnames(MVs(y)[[h]])
    ww[[h]]<-vv
  }
  weights(y)<-ww
  attr(y,"modes") <-modes
  attr(y,"scheme") <-scheme
  attr(y,"procedure") <-procedure
  class(y) =  append(class(y),"pplspm")
  return(y)
}

#' @title Test if its argument is  \code{pplspm}.
#' @description  \code{is.pplspm(x) } tests if its argument is \code{plspm}.
#' @param x an \code{R} object.
#' @return   a logical value.
#' @keywords internal
#' @export is.pplspm
is.pplspm <- function(x) {
  if(!(!is.null(attr(x, "modes"))& !is.null(attr(x, "procedure"))&!is.null(attr(x, "scheme")))) return(FALSE) else return(TRUE)
}

#' @title Turn to a list of \code{cplspm}
#' @description
#' \code{as.cplspm} Turn to a list of  \code{cplspm}
#' @param x a \code{pplspm}
#' @return Returns  list of \code{cplspm}.
#' @export as.cplspm
as.cplspm <-  function(x) {

  UseMethod("as.cplspm")
}
#' @export
as.cplspm.default<- function(x) {
  if (!is.pplspm(x)) stop("\n'as.cplspm equires pplspm.")

}
#' @export
as.cplspm.pplspm  <- function(x)
{
  #checking
  y=weights(x)
  for(h in 1 : length(x)){
    attr(y[[h]],"data") <-MVs(x)[[h]]
    attr(y[[h]], "parts") <-blocking(x)
    attr(y[[h]], "path_matrix") <- path.matrix(x)
    attr(y[[h]], "start") <- start(x)[[h]]
    attr(y[[h]], "modes") <- modes(x)
    attr(y[[h]], "scheme") <- scheme(x)
    attr(y[[h]], "tol") <- tol(x)
    attr(y[[h]], "maxiters") <- maxiters(x)
    attr(y[[h]], "procedure") <- procedure(x)
    class(y[[h]]) = append("cpmm","cplspm")
  }
  return(y)
}


