#' @title Lohmoller's iterative procedure
#' @description  computes and updates weights by those of plspm.
#' @param x :  a \code{cplspm}
#' @param printin  logical value for printing convergence information.
#' @return x updated
#' @examples
#' data(cheese)
#' path_matrix <- matrix(c(0, 0, 0,1, 0, 0,1, 1, 0),3,3)
#' blocks=list(chim=4:8,rheo=9:10,senso=11:16)
#' x=cpmm(cheese, blocks, path_matrix)
#' x=cplspm(x)
#' xx=lohmoller(x,printin=TRUE)
#' weights(x)
#' weights(xx)
#' @export lohmoller
lohmoller  <- function(x,printin){
  UseMethod("lohmoller")
}
#' @export
lohmoller.default <- function(x,printin)
{
  if (!is.cplspm(x))
    stop("\n'lohmoller()' requires a cpslpm .")
}
#' @export
lohmoller.cplspm <- function(x, printin=FALSE){
  if(!is.logical(printin)|length(printin)!=1)stop("\n'lohmoller.cplspm' printin must be logical value .")
  xx=MVs(x)
  if(is.null(attributes(xx)[["scaled:center"]])) stop("\n'lohmoller.cplspm' manifest variables must be centred .")
  modes=modes(x)
  parts = blocking(x)
  n=dim(xx)[1]
  p=dim(xx)[2]
  yy=matrix(0,p,n)
  # compute the inversion or do not compute the inverse at each iteration if mode B is considered
  aux1=0
  aux2=0
  for (k in 1:length(parts)){
    aux1=aux1+1
    aux2=aux2+parts[k]
    yy[aux1:aux2,]=switch(modes[k],A= (1/(n-1))*t(xx[,aux1:aux2]),B =ginv(t(xx[,aux1:aux2])%*%xx[,aux1:aux2])%*%t(xx[,aux1:aux2]))
    aux1 = aux2
  }
# recover specifications
  itermax=maxiters(x)
  tol=tol(x)
  scheme=scheme(x)
  C=path.matrix(x)+t(path.matrix(x))
  w0=start(x)
  w1=weights(x)
  w0=bvec2diag(w0,parts)# convert to a matrix
  w1=bvec2diag(w1,parts)
  ############################################
  # starting vectors of weights with Lohmoller's notation
  ############################################
  # Main computation steps following Hanafi(2007)
  iter=0
  diff0=(1/length(parts))*norm(xx%*%(w1-w0),'f')^2
  if(diff0<=tol){# if converges
    procedure(x)<-'lohmoller'
    attr(x,"error")<-diff0
    attr(x,"iter_Obs")<-0
    if(printin) cat(procedure(x),"=>", "iter =",0,"  accuracy  =", formatC(diff0, format = "e", digits = 0),"\n")
  }
  else {
    diff=rep(0,itermax)
    while(iter<itermax & diff0>tol){
      iter=iter+1
      lvs0=xx%*%w0 # or call lvs(x0)
      theta=switch(scheme,factorial= ((1/(n-1))*t(lvs0)%*%lvs0)*C,centroid = sign(((1/(n-1))*t(lvs0)%*%lvs0))*C)
      Z =lvs0%*%theta  #compute matrix Z see hanafi(2007)
      aux1=0
      aux2=0
      # update weights with mode A versus mode B
      for (k in 1:length(parts)){
        aux1=aux1+1
        aux2=aux2+parts[k]
        w1[aux1:aux2,k] = yy[aux1:aux2,]%*%Z[,k]
        aux1 = aux2
      }
      d=apply(xx%*%w1,2,'sd')
      dinv=1/d
      dinv[d < .Machine$double.eps]<-0 # update latent variable by 0 if has std=0
      w1=w1%*%diag(dinv)
      diff0=(1/length(parts))*norm(xx%*%(w1-w0),'f')^2
      diff[iter]=diff0
      w0=w1
     }
    #save the results
    weights(x)<-as.vector(w1%*%rep(1,length(parts)))
    procedure(x)<-'lohmoller'
    attr(x,"error")<-diff[1:iter]
    attr(x,"iter_Obs")<-iter
    if(printin) cat(procedure(x),"=>", "iter =",iter,"  accuracy  =", formatC(diff[iter], format = "e", digits = 0),"\n")
  }

    return(x)
}

#' @title  Laplacian's iterative procedure
#' @description \code{laplacian} computes and updates weights by those of plspm.
#' @param x :  a \code{cplspm}
#' @param printin  logical value for printing convergence information.
#' @return x updated.
#' @examples
#' data(cheese)
#' path_matrix <- matrix(c(0, 0, 0,1, 0, 0,1, 1, 0),3,3)
#' blocks=list(chim=4:8,rheo=9:10,senso=11:16)
#' x=cpmm(cheese, blocks, path_matrix)
#' x=cplspm(x)
#' xx=laplacian(x,printin=TRUE)
#' weights(x)
#' weights(xx)
#' @export laplacian
laplacian  <- function(x,printin){
  UseMethod("laplacian")
}
#' @export
laplacian.default <- function(x, printin)
{
  if (!is.cplspm(x)) stop("\n'laplacian()' requires a cpslpm or pplspm .")
}

#' @export
laplacian.cplspm <- function(x,printin=FALSE){

  if(!is.logical(printin)|length(printin)!=1)stop("\n'laplacian.cplspm' printin must be logical value .")
  xx=MVs(x)
  if(is.null(attributes(xx)[["scaled:center"]])) stop("\n'laplacian.cplspm' manifest variables must be centred .")
  modes=modes(x)
  parts = blocking(x)
  n=dim(xx)[1]
  p=dim(xx)[2]
  yy=matrix(0,p,n)
  aux1=0
  aux2=0

  # compute the inversion
  for (k in 1:length(parts)){
    aux1=aux1+1
    aux2=aux2+parts[k]
    yy[aux1:aux2,]=switch(modes[k],A= (1/(n-1))*t(xx[,aux1:aux2]),B =ginv(t(xx[,aux1:aux2])%*%xx[,aux1:aux2])%*%t(xx[,aux1:aux2]))
    aux1 = aux2
  }

  itermax=maxiters(x)
  tol=tol(x)
  scheme=scheme(x)
  C=path.matrix(x)+t(path.matrix(x))
  D= diag(rowSums(C))
  w0=start(x)
  w1=weights(x)
  w0=bvec2diag(w0,parts)# convert to a matrix
  w1=bvec2diag(w1,parts)
  ############################################
  # starting vectors of weights with Lohmoller's notation
  ############################################
  # Main computation steps following Hanafi(2007)
  iter=0
  diff0=(1/length(parts))*norm(xx%*%(w1-w0),'f')^2
  if(diff0<tol){# if converges
    procedure(x)<-'laplacian'
    attr(x,"error")<-diff0
    attr(x,"iter_Obs")<-0
    if(printin) cat(procedure(x),"=>", "iter =",0,"  accuracy  =", formatC(diff0, format = "e", digits = 0),"\n")
  }
  else {
    diff=rep(0,itermax)
    while(iter<itermax & diff0>tol){
      iter=iter+1
      lvs0=xx%*%w0 # or call lvs(x0)
      theta=switch(scheme,factorial= ((1/(n-1))*t(lvs0)%*%lvs0)*C,centroid = sign(((1/(n-1))*t(lvs0)%*%lvs0))*C)
      Z =lvs0%*%theta  #compute matrix Z see hanafi(2007)
      aux1=0
      aux2=0
      # update weights with mode A versus mode B
      for (k in 1:length(parts)){
        aux1=aux1+1
        aux2=aux2+parts[k]
        w1[aux1:aux2,k] =D[k]*w1[aux1:aux2,k]+ yy[aux1:aux2,]%*%Z[,k]
        aux1 = aux2
      }
      d=apply(xx%*%w1,2,'sd')
      dinv=1/d
      dinv[d < .Machine$double.eps]<-0 # update latent variable by 0 if has std=0
      w1=w1%*%diag(dinv)
      diff0=(1/length(parts))*norm(xx%*%(w1-w0),'f')^2
      diff[iter]=diff0
      w0=w1
    }
    #save the results
    #save the results
    weights(x)<-as.vector(w1%*%rep(1,length(parts)))
    procedure(x)<-'laplacian'
    attr(x,"error")<-diff[1:iter]
    attr(x,"iter_Obs")<-iter
    if(printin) cat(procedure(x),"=>", "iter =",iter,"  accuracy  =", formatC(diff[iter], format = "e", digits = 0),"\n")
  }

  return(x)
}

#' @title  Hanafi-Wold's iterative procedure
#' @description
#' \code{hanafi_wold} computes and updates weights by those of plspm.
#' @param x :  a \code{cplspm}
#' @param printin  logical value for printing convergence information.
#' @return x updated.
#' @export hanafi_wold
#' @examples
#' data(cheese)
#' path_matrix <- matrix(c(0, 0, 0,1, 0, 0,1, 1, 0),3,3)
#' blocks=list(chim=4:8,rheo=9:10,senso=11:16)
#' x=cpmm(cheese, blocks, path_matrix)
#' x=cplspm(x)
#' xx=hanafi_wold(x,printin=TRUE)
#' weights(x)
#' weights(xx)
hanafi_wold  <- function(x,printin){
  UseMethod("hanafi_wold")
}
#' @export
hanafi_wold.default <- function(x,printin)
{
  if (!is.cplspm(x)) stop("\n'hanafi_wold()' requires a cpslpm or pplspm .")
}

#' @export
hanafi_wold.cplspm <- function(x,printin=FALSE){
  if(!is.logical(printin)|length(printin)!=1)stop("\n'hanafi_wold.cplspm' printin must be logical value .")
  xx=MVs(x)
  if(is.null(attributes(xx)[["scaled:center"]])) stop("\n'hanafi_wold.cplspm' manifest variables must be centred .")

  modes=modes(x)
  parts = blocking(x)
  n=dim(xx)[1]
  p=dim(xx)[2]
  yy=matrix(0,p,n)
  # compute the inversion or do not compute the inverse at each iteration if mode B is considered
  aux1=0
  aux2=0
  for (k in 1:length(parts)){
    aux1=aux1+1
    aux2=aux2+parts[k]
    yy[aux1:aux2,]=switch(modes[k],A= (1/(n-1))*t(xx[,aux1:aux2]),B =ginv(t(xx[,aux1:aux2])%*%xx[,aux1:aux2])%*%t(xx[,aux1:aux2]))
    aux1 = aux2
  }
  # recover specifications
  itermax=maxiters(x)
  tol=tol(x)
  scheme=scheme(x)
  C=path.matrix(x)+t(path.matrix(x))
  w0=start(x)
  w1=weights(x)
  w0=bvec2diag(w0,parts)# convert to a matrix
  w1=bvec2diag(w1,parts)
  ############################################
  # starting vectors of weights with Lohmoller's notation
  ############################################
  # Main computation steps following Hanafi(2007)
  iter=0
  diff0=(1/length(parts))*norm(xx%*%(w1-w0),'f')^2
  if(diff0<tol){# if converges
    procedure(x)<-'hanafi_wold'
    attr(x,"error")<-diff0
    attr(x,"iter_Obs")<-0
    if(printin) cat(procedure(x),"=>", "iter =",0,"  accuracy  =", formatC(diff0, format = "e", digits = 0),"\n")
  }

  else {
    diff=rep(0,itermax)
    lvs0=xx%*%w0 # or call lvs(x0)
    theta=switch(scheme,factorial= ((1/(n-1))*t(lvs0)%*%lvs0)*C,centroid = sign(((1/(n-1))*t(lvs0)%*%lvs0))*C)
    Z =lvs0%*%theta

    while(iter<itermax & diff0>tol){
      iter=iter+1
      aux1 = 0
      aux2=0
    for (k in 1:length(parts)){
        aux1=aux1+1
        aux2=aux2+parts[k]
        w1k=yy[aux1:aux2,]%*%Z[,k]
        d= sd(xx[,aux1:aux2]%*%w1k)
        dinv=1/d
        if(d < .Machine$double.eps) dinv=0
        w1k=dinv*w1k
        w1[aux1:aux2,k]=w1k
        lvsk=xx%*%w1
        thetak=switch(scheme,factorial= ((1/(n-1))*t(lvsk)%*%lvsk)*C,centroid = sign(((1/(n-1))*t(lvsk)%*%lvsk))*C)
        Z =lvsk%*%thetak
        aux1 = aux2
    }
      diff0=(1/length(parts))*norm(xx%*%(w1-w0),'f')^2
      diff[iter]=diff0
      w0=w1
    }
    #save the results
    weights(x)<-as.vector(w1%*%rep(1,length(parts)))
    procedure(x)<-'hanafi_wold'

    attr(x,"error")<-diff[1:iter]
    attr(x,"iter_Obs")<-iter
    if(printin) cat(procedure(x),"=>", "iter =",iter,"  accuracy  =", formatC(diff[iter], format = "e", digits = 0),"\n")
  }

  return(x)
}
