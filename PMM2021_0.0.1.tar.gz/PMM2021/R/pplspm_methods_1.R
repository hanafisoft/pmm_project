
#' @export

modes.pplspm<- function(x)
{
  return(attr(x,"modes"))
}

#' @export
"modes<-.pplspm"<- function(x,value)
{
  if (!is.character(value)) stop("\n modes<-() requires a character vector ")
  if ((length(modes(x))!=length(value))) stop("\n modes<-() must match with the number of blocks.")
  if(!(all((value=='B')|(value=='A')))) stop("\n'modes' possible values are A or B")
  attr(x, "modes") <-value
  return(x)
}



#' @export
scheme.pplspm <- function(x)
{
  return(attr(x,"scheme"))
}


#' @export
"scheme<-.pplspm"<- function(x,value)
{
  if (!is.character(value)) stop("\n scheme<-() requires a character vector ")
  if (!(value=='centroid' | value =='factorial' | value =='path'))  stop("\n invalid value for scheme.")

  attr(x, "scheme") <-value
  return(x)
}


#' @export
procedure.pplspm <- function(x)
{
  return(attr(x,"procedure"))
}



#' @export
"procedure<-.pplspm"<- function(x,value)
{
  if (!is.character(value)) stop("\n procedure<-() requires a character vector ")
  if (!(value=='lohmoller' | value =='laplacian' | value =='hanafi_wold'))  stop("\n not valid procedure name .")
  attr(x, "procedure") <-value
  return(x)
}

