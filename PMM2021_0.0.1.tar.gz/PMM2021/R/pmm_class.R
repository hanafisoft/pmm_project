#' @title  Predictive Multiblock Model \cr
#' @description
#' \code{pmm} creates a Predictive Multiblock Model \code{pmm} \cr
#' \code{is.pmm()} tests if its argument is a \code{pmm} .\cr
#' \code{as.pmm()} attempts to turn a list of \code{cpmm} to a \code{pmm}.\cr
#' @param data  matrix or data frame containing  manifest quantitative variables.
#' @param blocks  list of integer vectors indicating the sets of manifest variables forming each block.
#' @param path_matrix  an adjacency matrix of an oriented graph.
#' @param scaled  optionnal logical value. Default value data is scaled, otherwise data is only centred.
#' @param dim  an integer value the desired dimension of  (\code{pmm}).\cr
#' @param w  list of numeric vectors. The weights vectors
#' @param start list of numeric vectors. The starting vectors of weights
#' @param tol  upper bound of the expected mean squares Frobenius norm of the error.
#' @param maxiters upper bound of the expected number of iterations.
#' @param names  a character vector. Names of each dimension of \code{pmm} \cr
#' @importFrom "stats"  "runif"
#' @export pmm
#' @examples
#' data(cheese)
#' path_matrix <- matrix(c(0, 0, 0,1, 0, 0,1, 1, 0),3,3)
#' blocks=list(chim=4:8,rheo=9:10,senso=11:16)
#' x=pmm(cheese, blocks, path_matrix,dim=3)
pmm <- function(data, blocks=NULL, path_matrix=NULL,scaled=TRUE, w=NULL,start=NULL,dim=1,tol=1e-05,maxiters=50, names=NULL){


  #checking
  if(is.null(data)|!(is.matrix(data)|is.data.frame(data)))
    stop("\n'pmm' data must be a matrix or data frame.")

  if(is.null(blocks) | !is.list(blocks)) stop("\n'pmm' blocks must be a list  .")
  if(!all(unlist(lapply(blocks,is.integer)))) stop("\n'pmm' blocks must a list of integer vectors .")

  if(max(unlist(lapply(blocks,max)))>dim(data)[2])
    stop("\n'pmm' blocks' : components of blocks must be less than or equal the number of columns of data.")

  if(is.null(path_matrix)) stop("\n'pmm'  invalid. path_matrix.")
  if(!(is.matrix(path_matrix)|all(dim(path_matrix)==c(length(blocks),length(blocks)))))
    stop("\n'pmm'  invalid dimension of path_matrix.")
  M=path_matrix
  M[lower.tri(M,diag=TRUE)] <-0
  if(!(all(M==path_matrix))) stop("\n'pmm' path matrix' must be adjacency matrix of an oriented graph")
  if(!all((M==1)|(M==0)))stop("\n'pmm' possible values for the path matrix are  0 or 1 .")
  if(is.null(names(blocks))) names(blocks)<-paste('Block',1:length(blocks))
  rownames(path_matrix)<-names(blocks)
  colnames(path_matrix)<-names(blocks)

   x=as.matrix(data[,unlist(blocks)])
  if(!all(unlist(lapply(x, is.numeric)))) stop("\n'pmm' 'data' manifest variables must be numeric.")
  parts = unlist(lapply(blocks, length))
  names(parts)<-names(blocks)
  if((as.integer(dim) != dim) | length(dim)!=1) stop("\n'pmm' dim must be integer ")
  if(is.null(names)) names=paste('dim', 1:dim)
  if(!(!is.null(names) & is.character(names) & (length(names)==dim))) stop("\n'pmm'  invalid  names ")
  if(is.null(rownames(x))) rownames(x)<-paste('row',1:dim(x)[1])
  if(is.null(colnames(x))) colnames(x)<-paste('col',1:dim(x)[1])

  if(is.null(w)){
    m=matrix(runif(dim(x)[2]*dim),dim(x)[2],dim)
               rownames(m)<-colnames(x)
               w<-lapply(seq_len(ncol(m)), function(x) m[,x])
               names(w)<-names
  }


  if(!(!is.null(w) & all(as.vector(do.call(rbind,lapply(w,is.numeric)))) & all(as.vector(do.call(rbind,lapply(w,length))==dim(x)[2])))) stop("\n'w'  must be a numeric with compatible dimension or length with data ")
  names(w)<-names

  if(is.null(start)){
    m=matrix(runif(dim(x)[2]*dim),dim(x)[2],dim)
    rownames(m)<-colnames(x)
    start<-lapply(seq_len(ncol(m)), function(x) m[,x])
  }
  if(!(!is.null(start) & all(as.vector(do.call(rbind,lapply(start,is.numeric)))) & all(as.vector(do.call(rbind,lapply(start,length))==dim(x)[2])))) stop("\n'start'  must be a numeric with compatible dimension or length with data ")
  names(start)<-names

  if(!(as.integer(maxiters)==maxiters & length(maxiters)==1))     stop("\n'pmm' maxiters' must be an integer value")
  if(!(is.numeric(tol) & length(tol)==1 & tol>=0)) stop("\n'pmm' tol must be a positive numeric value")

  if(scaled) x<-scale(x) else x<-scale(x,scale=FALSE)

  attr(w, "data") <-rep(list(x),dim)
  names(attr(w, "data"))<-names
  attr(w, "parts") <-parts
  attr(w, "path_matrix") <- path_matrix
  attr(w, "start") <- start
  attr(w, "tol") <- tol
  attr(w, "maxiters") <- maxiters
  attr(w,"names")<-names
  class(w) = "pmm"
  return(w)
}

#' @title Is  \code{pmm} ?.
#' @description  tests if its argument is  \code{cpmm}.
#' @param x an \code{R} object.
#' @return   a logical value.
#' @keywords internal
#' @export is.pmm
is.pmm <- function(x){
    return(all(c("data","names","parts","path_matrix","start","tol","maxiters","names") %in%names(attributes(x))))
}
#' @title Turn to a list of \code{cpmm}
#' @description
#' \code{as.cpmm} Turn to a list of  \code{cpmm}
#' @param x a \code{pmm}
#' @return Returns  list of \code{cpmm}.
#' @export as.cpmm
as.cpmm <-  function(x) {

  UseMethod("as.cpmm")
}
#' @export
as.cpmm.default<- function(x) {
  if (!is.pmm(x)) stop("\n'as.cpmm requires pmm.")

}
#' @export
as.cpmm.pmm  <- function(x)
{
  #checking
  y=weights(x)
  for(h in 1 : length(x)){
    attr(y[[h]],"data") <-MVs(x)[[h]]
    attr(y[[h]], "parts") <-blocking(x)
    attr(y[[h]], "path_matrix") <- path.matrix(x)
    attr(y[[h]], "start") <- start(x)[[h]]
    class(y[[h]]) = "cpmm"
  }
  return(y)
}

