#' @title Modes
#' @description
#' \code{modes} allows to recover the modes of a \code{cplspm} or \code{pplspm}
#' @details
#' Use \code{modes<-value} to update modes of a \code{cplspm}  or \code{pplspm}.
#' @param x a  \code{cplspm} or \code{pplspm}.
#' @return Returns a character vector.
#' @examples
#' data(cheese)
#' path_matrix <- matrix(c(0, 0, 0,1, 0, 0,1, 1, 0),3,3)
#' blocks=list(chim=4:8,rheo=9:10,senso=11:16)
#' x=cpmm(cheese, blocks, path_matrix)
#' x=cplspm(x)
#' modes(x)
#' modes(x)<-c("A","B","A")
#' @export modes

modes  <- function(x){
  UseMethod("modes", x)
}
#' @export
modes.default <- function(x)
{
  if (!(is.cplspm(x)|is.pplspm(x)))
    stop("\n'modes()' requires a cplspm or pplspm.")
}
#' @export
modes.cplspm<- function(x)
{
  return(attr(x,"modes"))
}
#' @title Update modes
#' @description  Update modes for a \code{cplspm} or  \code{pplspm}\cr
#' @param x a \code{cplspm} or a \code{pplspm}.
#' @param value a  character vector.
#' @return  a \code{cplspm} or  \code{plspm}
#' @keywords internal
#' @export "modes<-"
"modes<-" <-  function(x,value) {
  UseMethod("modes<-")
}
#' @export
"modes<-.default" <- function(x,value)
{
  if (!(is.cplspm(x)|is.pplspm(x)))
    stop("\n modes<-() requires a cplspm or pplspm .")
}
#' @export
"modes<-.cplspm"<- function(x,value)
{
  if (!is.cplspm(x)) stop("\n modes<-.cplspm() requires a cplspm ")
  if (!is.character(value)) stop("\n modes<-.cplspm() requires a character vector ")
  if (length(modes(x))!=length(value)) stop("\n modes<-.cplspm() must match with the number of blocks.")
  if(!(all((value=='B')|(value=='A')))) stop("\n'modes<-.cplspm()' possible values are A or B")
  xnew=x
  attr(xnew, "modes") <-value
  return(xnew)
}


#' @title Weighting scheme
#' @description
#' \code{scheme} allows to recover the scheme of a \code{cplspm} or \code{pplspm}.
#' @details
#' Use \code{scheme<-value} to update scheme.\code{value} can be : 'centroid', 'factorial' or 'path'
#' @param x a \code{cplspm} or \code{pplspm}
#' @return Returns a string
#' @examples
#' data(cheese)
#' path_matrix <- matrix(c(0, 0, 0,1, 0, 0,1, 1, 0),3,3)
#' blocks=list(chim=4:8,rheo=9:10,senso=11:16)
#' x=cpmm(cheese, blocks, path_matrix)
#' x=cplspm(x)
#' scheme(x)
#' scheme(x)<-'centroid'
#' @export scheme
scheme  <- function(x){
  UseMethod("scheme", x)
}
#' @export
scheme.default <- function(x)
{
  if (!is.cplspm(x)|!is.pplspm(x))
    stop("\n'scheme()' requires an cplspm or pplspm.")
}
#' @export
scheme.cplspm <- function(x)
{
  return(attr(x,"scheme"))
}

#' @title Update  Wwighting scheme
#' @description  Update scheme for a \code{cplspm} or  \code{pplspm}\cr
#' @param x a \code{cplspm} or a \code{pplspm}.
#' @param value a string.
#' @return  a \code{cplspm} or  \code{plspm}
#' @keywords internal
#' @export "scheme<-"
"scheme<-" <-  function(x,value) {
  UseMethod("scheme<-")
}
#' @export
"scheme<-.default" <- function(x,value)
{
  if (!(is.cplspm(x)|is.pplspm(x)))
    stop("\n scheme<-() requires an cplspm or pplspm.")
}
#' @export
"scheme<-.cplspm"<- function(x,value)
{
  if (!is.cplspm(x)) stop("\n scheme<-() requires a cplspm model.")
  if (!is.character(value)) stop("\n scheme<-() requires a character vector ")
  if (!(value=='centroid' | value =='factorial' | value =='path'))  stop("\n invalid value for scheme.")

  attr(x, "scheme") <-value
  return(x)
}

#' @title Name of the plspm iterative procedure
#' @description
#' \code{procedure} gives the name of the expected iterative procedure to compute plspm weights of a \code{cplspm} or \code{pplspm}\cr
#' @details
#' Use \code{procedure<-value} to update the name of the iterative procedure. \cr Possible names are : 'lohmoller', 'laplacian' or 'hanafi_wold'
#' @param x a \code{cplspm} or \code{pplspm}
#' @return Returns a string
#' @examples
#' data(cheese)
#' path_matrix <- matrix(c(0, 0, 0,1, 0, 0,1, 1, 0),3,3)
#' blocks=list(chim=4:8,rheo=9:10,senso=11:16)
#' x=cpmm(cheese, blocks, path_matrix)
#' x=cplspm(x)
#' procedure(x)
#' procedure(x)<-'laplacian'
#' @export procedure


procedure  <- function(x){
  UseMethod("procedure")
}
#' @export
procedure.default <- function(x)
{
  if (!(is.cplspm(x)|is.pplspm(x)))
    stop("\n'procedure()' requires a cpslpm or pplspm .")
}
#' @export
procedure.cplspm <- function(x)
{
  return(attr(x,"procedure"))
}


#' @title Update name of the procedure to be used
#' @description  Update procedure for a \code{cplspm} or  \code{pplspm}\cr
#' @param x a \code{cplspm} or a \code{pplspm}.
#' @param value a string.
#' @return  a \code{cplspm} or  \code{plspm}
#' @keywords internal
#' @export "procedure<-"

"procedure<-" <-  function(x,value) {
  UseMethod("procedure<-")
}
#' @export
"procedure<-.default" <- function(x,value)
{
  if (!(is.cplspm(x)|is.pplspm(x)))
    stop("\n'procedure()' requires a cpslpm or pplspm .")
}
#' @export
"procedure<-.cplspm"<- function(x,value)
{
  if (!is.character(value)) stop("\n procedure<-() requires a character vector ")
  if (!(value=='lohmoller' | value =='laplacian' | value =='hanafi_wold'))  stop("\n not valid procedure name .")
  attr(x, "procedure") <-value
  return(x)
}

