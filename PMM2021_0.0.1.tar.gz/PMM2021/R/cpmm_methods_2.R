#' @title store blocks of a partitionned vector on a block diagonal matrix. Diagonal blocks are the blocks of the partitioned vector.
#' @description Turn a block vector to a block diagonal matrix
#' \code{bvec2diag}. transform a partitioned vector to a block diagonal matrix \cr
#' @param x a numeric vector.
#' @param parts an integer vector representing a (so-called integer partition) of the \code{length} of x .
#' @return Returns a block diagonal matrix
#' @keywords internal
#' @export bvec2diag
bvec2diag<-function(x,parts){
  if(is.null(x)| is.null(parts))     stop("\n' NULL value is excluded for the two arguments. ")
  if(!(is.numeric(x)& sum(parts)==length(x)))     stop("\n' sum of pars must be equal the length of x. ")
  xx=matrix(0,nrow=sum(parts),ncol=length(parts))
  aux1=0
  aux2=0
  for (i in 1:length(parts)){
    aux1=aux1+1
    aux2=aux2+parts[i]
    xx[aux1:aux2,i]=x[aux1:aux2]
    aux1=aux2
  }
  return(xx)
}
#' @title Composites
#' @description Get composites of a \code{cpmm} or  \code{pmm} .
#' @param x a \code{cpmm} or  \code{pmm} .
#' @return Returns a numeric matrix for a \code{cpmm}. \cr Returns a list of numeric matrices for \code{pmm}
#' @export lvs
#' @examples
#' data(cheese)
#' path_matrix <- matrix(c(0, 0, 0,1, 0, 0,1, 1, 0),3,3)
#' blocks=list(chim=4:8,rheo=9:10,senso=11:16)
#' x=cpmm(cheese, blocks, path_matrix)
#' lvs(x)
lvs  <- function(x){
  UseMethod("lvs", x)
}
#' @export
lvs.default <- function(x)
{
  if (!(is.cpmm(x)|is.pmm(x)))
    stop("\n'lvs()' requires an cpmm or pmm .")
}
#' @export
lvs.cpmm <- function(x)
{
  a=MVs(x)%*%bvec2diag(weights(x),blocking(x))
  rownames(a)<-rownames(MVs(x))
  colnames(a)<-names(blocking(x))
  return(a)
}

#' @title Loadings
#' @description  Get loadings of a \code{cpmm} or \code{pmm} .
#' @param x a \code{cpmm} or \code{pmm} .
#' @return Returns a numeric vector of loadings for an \code{cpmm} or a list of numeric vectors of a \code{pmm} .
#' @export loadings
#' @aliases loadings
#' @examples
#' data(cheese)
#' path_matrix <- matrix(c(0, 0, 0,1, 0, 0,1, 1, 0),3,3)
#' blocks=list(chim=4:8,rheo=9:10,senso=11:16)
#' x=cpmm(cheese, blocks, path_matrix)
#' loadings(x)
loadings  <- function(x){
  UseMethod("loadings", x)
}
#' @export
loadings.default <- function(x)
{
  if (!(is.cpmm(x)|is.pmm(x)))
    stop("\n'loadings()' requires an cpmm or pmm .")
}
#' @export
loadings.cpmm <- function(x)
{
  xx=MVs(x)
  parts=blocking(x)
  lvs1=lvs(x)
  LAMDA=numeric(sum(parts))
  aux1=0
  aux2=0
  for (k in 1:length(parts)){
    aux1=aux1+1
    aux2=aux2+parts[k]
    LAMDA[aux1:aux2] = (1/as.vector(t(lvs1[,k])%*% lvs1[,k]))*(t(xx[,aux1:aux2])%*% lvs1[,k])
    aux1 =aux2
  }
  names(LAMDA)<-colnames(xx)
  return(LAMDA)
}

#' @title Path coefficients.
#' @description Get matrix of path coefficients of a  \code{cpmm} or \code{pmm} .
#' @param x \code{cpmm} or \code{pmm} .
#' @return Returns the matrix of path ceofficients for a \code{cpmm} or a list of matrices of path ceofficients for a \code{pmm} .
#' @importFrom "stats"  "lm"
#' @export path.coeffs
#' @aliases path.coeffs
#' @examples
#' data(cheese)
#' path_matrix <- matrix(c(0, 0, 0,1, 0, 0,1, 1, 0),3,3)
#' blocks=list(chim=4:8,rheo=9:10,senso=11:16)
#' x=cpmm(cheese, blocks, path_matrix)
#' path.coeffs(x)

path.coeffs  <- function(x){
  UseMethod("path.coeffs", x)
}
#' @export
path.coeffs.default <- function(x)
{
  if (!is.cpmm(x)|!is.pmm(x))
    stop("\n'path.coeffs()' requires a cpmm or pmm .")
}
#' @export
path.coeffs.cpmm <- function(x)
{

  path_matrix=path.matrix(x)
  lvs1=lvs(x)
  endo = colSums(path_matrix)
  endo[endo!=0] <- 1  # # endogenous LV
  exog <- colSums(path_matrix)==0
  BETA <- path_matrix
  for (aux in 1:ncol(path_matrix)) {
    if (endo[aux] == 1) # endogenous LV
    {
      c <- which(path_matrix[1:aux,aux]==1)
      BETA[c,aux] <- t(summary(lm(lvs1[,aux] ~ lvs1[,c]))$coef[-1,1])
    }
  }
  return(BETA)
}
################################################
