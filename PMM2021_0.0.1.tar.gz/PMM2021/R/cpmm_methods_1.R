#' @title  Manifest Variables
#' @description  Get manifest variables for a \code{cpmm} or  \code{pmm}.\cr
#' @details
#' Use \code{MVs(x)<-value} to update manifest variables. \code{value} must have the same number of manifest variables as the current ones \cr
#' for a \code{cpmm}, value must be a numeric  matrix.\cr
#' for a  \code{pmm}, value must be a list of numeric matrices.\cr
#' @param x a \code{cpmm} or \code{pmm}.
#' @return  a matrix of manifest variables for \code{cpmm}.\cr  a list of matrices of manifest variables for \code{pmm}.\cr
#' @export MVs
#' @examples
#' data(cheese)
#' path_matrix <- matrix(c(0, 0, 0,1, 0, 0,1, 1, 0),3,3)
#' blocks=list(chim=4:8,rheo=9:10,senso=11:16)
#' x=cpmm(cheese, blocks, path_matrix)
#' MVs(x)
#' MVs(x)<-scale(MVs(x))

MVs  <- function(x){
  UseMethod("MVs")
}


#' @export
MVs.default <- function(x)
{
  if (!is.cpmm(x)|!is.pmm(x))
    stop("\n'MVs()' requires a cpmm or pmm .")
}
#' @export
MVs.cpmm <- function(x)
{
  return(attr(x,"data"))
}
#' @title Update Manifeste variables
#' @description  Update manifest variables for a \code{cpmm} or  \code{pmm}\cr
#' \code{MVs(x)<-value} allows to update manifest variables of a \code{cpmm} or a \code{pmm}.\cr
#' @param x a \code{cpmm} or a \code{pmm}.
#' @param value a  matrix or a list of matrices.
#' @return  a \code{cpmm} or  \code{pmm}
#' @keywords internal
#' @export "MVs<-"
"MVs<-" <-  function(x,value) {
  UseMethod("MVs<-")
}
#' @export
"MVs<-.default" <- function(x,value)
{
  if (!is.cpmm(x)|!is.pmm(x))
    stop("\n MVs<-() requires a cpmm .")
}
#' @export
"MVs<-.cpmm"<- function(x,value)
{
  if (!is.matrix(value)) stop("\n MVs<-() requires as matrix of MVs ")
  if ((!is.numeric(value)|dim(value)[2]!=dim(MVs(x))[2])) stop("\n MVs<-() :  number of colums must be identical to the number of manifest variables.")
  attr(x, "data") <-value
  return(x)
}

#' @title Number of manifest variables by block
#' @description Get the number of manifest variables by block for \code{cpmm} or \code{pmm}
#' @details
#' Use \code{blocking(x)<-value} to update the partition of manifest variables.\cr
#' value must be an integer vector.\cr
#' \code{blocking(x)<-value} returns  a \code{cpmm} or \code{pmm}.
#' @param x a \code{cpmm}.
#' @return Returns an integer vector representing the number of manifest variables by block.
#' @export blocking
#' @examples
#' data(cheese)
#' path_matrix <- matrix(c(0, 0, 0,1, 0, 0,1, 1, 0),3,3)
#' blocks=list(chim=4:8,rheo=9:10,senso=11:16)
#' x=cpmm(cheese, blocks, path_matrix)
#' blocking(x)
blocking  <- function(x){
  UseMethod("blocking")
}
#'@export
blocking.default <- function(x)
{
  if (!(is.cpmm(x)| is.pmm(x)) )
    stop("\n'blocking ' requires an cpmm or pmm .")
}
#'@export
blocking.cpmm <- function(x)
{
  return(attr(x,"parts"))
}

###
#' @title Update the number of manifest variables by blocks
#' @description Update the number of manifest variables by blocks.
#' @param x an \code{cpmm} or \code{pmm}.
#' @param value an integer \code{vector}.  .
#' @return  a \code{cpmm} or \code{pmm}
#' @keywords internal
#' @export "blocking<-"
"blocking<-" <-  function(x,value) {
  UseMethod("blocking<-")
}
#' @export
"blocking<-.default" <- function(x,value)
{
  if (!(is.cpmm(x)| is.pmm(x)) )
    stop("\n blocking<-() requires a cpmm or pmm .")
}
#' @export
"blocking<-.cpmm"<- function(x,value)
{
  if (!is.vector(value)) stop("\n blocking<-() requires value as vector  ")
  if (!is.numeric(value)) stop("\n blocking<-() :  value must be integer vector.")
  if (! (length(value)==length(blocking(x)) & sum(value)==sum(blocking(x)))) stop("\n blocking<-()<-() :  invalid length .")

  names(value)<-names(blocking(x))
  attr(x, "parts") <-value
  return(x)
}


#' @title Path or Adjacency matrix
#' @description  Get  the adjacency matrix of a \code{cpmm} or \code{pmm}.\cr
#'@details
#' Use \code{path.matrix<-value} to update path matrix  of a \code{cpmm} or  \code{pmm}\cr \code{value} must be an adjacency matrix
#' @param x a \code{cpmm} or \code{pmm}.
#' @return Returns an upper triangular binary and numeric matrix.
#' @export path.matrix
#' @examples
#' data(cheese)
#' path_matrix <- matrix(c(0, 0, 0,1, 0, 0,1, 1, 0),3,3)
#' blocks=list(chim=4:8,rheo=9:10,senso=11:16)
#' x=cpmm(cheese, blocks, path_matrix)
#' path.matrix(x)
#' path.matrix(x)<-matrix(c(0, 0, 0,1, 0, 0,0, 1, 0),3,3)
path.matrix  <- function(x){
  UseMethod("path.matrix")
}
#'@export
path.matrix.default <- function(x)
{
  if (!(is.cpmm(x)| is.pmm(x)) )
    stop("\n'path.matrix()' requires an cpmm or pmm .")
}
#'@export
path.matrix.cpmm <- function(x)
{
  return(attr(x,"path_matrix"))
}

#' @title Update Path matrix
#' @description  Update the adjacency matrix.
#' @param x an \code{cpmm} or \code{pmm}.
#' @param value an adjacency matrix.  .
#' @return  a \code{cpmm} or \code{pmm}
#' @keywords internal
#' @export "path.matrix<-"
"path.matrix<-" <-  function(x,value) {
  UseMethod("path.matrix<-")
}
#' @export
"path.matrix<-.default" <- function(x,value)
{
  if (!(is.cpmm(x)| is.pmm(x)) )
    stop("\n path.matrix<-() requires a cpmm or pmm .")
}
#' @export
"path.matrix<-.cpmm"<- function(x,value)
{
  if (!is.matrix(value)) stop("\n path.matrix<-() requires value as matrix  ")
  if (!(is.numeric(value) & (dim(value)[1]=dim(value)[2]))) stop("\n path.matrix<-() :  value must be a square matrix.")
  if (dim(value)[1]!=dim(path.matrix(x))[1]) stop("\n path.matrix<-() :  invalid dimension .")
  M=value
  M[lower.tri(M,diag=TRUE)] <-0
  if(!(all(M==value))) stop("\n'path matrix must be lower triangular matrix with diagonal=0.")
  if(!all((M==1)|(M==0)))stop("\n' not a binary numeric triangular  .")

  rownames(value)<-rownames(path.matrix(x))
  colnames(value)<-colnames(path.matrix(x))
  attr(x, "path_matrix") <-value
  return(x)
}

#' @title Weights.
#' @description \code{weights} allows to recover weights for a \code{cpmm} or \code{pmm}.
#'@details
#' Use \code{weights(x)<-value} to update starting vector of weight.\cr
#' for a \code{cpmm}, value must be a numeric \code{ vector}.\cr
#' for a a \code{pmm}, value must be a \code{list} of numeric vectors\cr
#' @param x a \code{cpmm} or a \code{pmm}
#' @return Returns a vector of weights for a \code{cpmm} or a list of vectors for a \code{pmm} .
#' @export weights
#' @examples
#' data(cheese)
#' path_matrix <- matrix(c(0, 0, 0,1, 0, 0,1, 1, 0),3,3)
#' blocks=list(chim=4:8,rheo=9:10,senso=11:16)
#' x=cpmm(cheese, blocks, path_matrix)
#' weights(x)
#' weights(x)<-rep(1,dim(MVs(x))[2])


weights  <- function(x){
  UseMethod("weights", x)
}
#' @export
weights.default <- function(x)
{
  if (!is.cpmm(x)|!is.pmm(x) )
    stop("\n'weights()' requires a cpmm or pmm .")
}
#' @export
weights.cpmm <- function(x)
{
  xx=x
  attributes(xx)<-NULL
  names(xx)<-colnames(MVs(x))
  return(xx)
}



#' @title Update Weights
#' @description Update vector of weights.
#' @param x a \code{cpmm} or a \code{pmm}
#' @param value a numerci vector for \code{cpmm} or a list of vectors for a \code{pmm}
#' @return a \code{cpmm} or a \code{pmm} .
#' @export "weights<-"
#' @keywords internal
"weights<-" <- function(x,value) {
  UseMethod("weights<-")
}
#' @export
"weights<-.default" <- function(x,value)
{
  if (!is.cpmm(x))
    stop("\n weights<-() requires a cpmm .")
}
#' @export
"weights<-.cpmm" <- function(x,value)
{
  if (length(value)!=length(weights(x)))
    stop("\n weights<-() not compatible length .")
  ss<-attributes(x)
  x<-as.numeric(value)
  attributes(x)<-ss
  return(x)
}

#' @title Starting vector of weights.
#' @description \code{start} allows to recover the starting vector of weights for a \code{cpmm} or \code{pmm}.
#'@details
#' Use \code{start(x)<-value} to update starting vector of weight.\cr
#' for a \code{cpmm}, value must be a numeric \code{ vector}.\cr
#' for a a \code{pmm}, value must be a \code{list} of numeric vectors\cr
#' @param x a \code{cpmm} or \code{pmm}.
#' @return  numeric vector for a \code{cpmm} or list of numeric vectors for \code{pmm}.
#' @export start
#' @examples
#' data(cheese)
#' path_matrix <- matrix(c(0, 0, 0,1, 0, 0,1, 1, 0),3,3)
#' blocks=list(chim=4:8,rheo=9:10,senso=11:16)
#' x=cpmm(cheese, blocks, path_matrix)
#' start(x)
#' start(x)<-runif(dim(MVs(x))[2])

start  <- function(x){
  UseMethod("start", x)
}
#' @export
start.default <- function(x)
{
  if (!(is.cpmm(x)|pmm(x)))
    stop("\n'start()' requires a cpmm or pplspm.")
}
#' @export
start.cpmm <- function(x)
{
  return(attr(x,"start"))
}
#' @title Update Starting vector of weights.
#' @description Update staring vector of weights.
#' @param x a \code{cpmm} or a \code{pmm}
#' @param value a numerci vector for \code{cpmm} or a list of vectors for a \code{pmm}
#' @return a \code{cpmm} or a \code{pmm} .
#' @export "start<-"
#' @keywords internal
#' @export "start<-"
"start<-" <-  function(x,value) {
  UseMethod("start<-")
}
#' @export
"start<-.default" <- function(x,value)
{
  if (!(is.cpmm(x)|pmm(x)))
    stop("\n'start()' requires a cpmm or pplspm.")
}
#' @export
"start<-.cpmm"<- function(x,value)
{

  if (length(value)!=length(start(x)))
    stop("\n start<-() not compatible length .")
  xnew=x
  attr(xnew,"start")<-as.numeric(value)
  return(xnew)

}
#' @export
tol.cpmm <- function(x)
{
  return(attr(x,"tol"))
}
#' @export
"tol<-.cpmm"<- function(x,value){
  if (!is.numeric(value)) stop("\n tol<-() requires an integer ")
  if (!(length(value)==1))  stop("\n tol<-() requires an numeric value")
  attr(x, "tol") <-value
  return(x)
}
#' @export
maxiters.cpmm <- function(x)
{
  return(attr(x,"maxiters"))
}
#' @export
"maxiters<-.cpmm"<- function(x,value){
  attr(x, "maxiters") <-value
  return(x)
}
