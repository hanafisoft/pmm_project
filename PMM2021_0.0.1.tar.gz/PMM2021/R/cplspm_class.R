#' @title Cell Predictive PLSPM Model (or \code{cplspm})
#' @description \code{cplspm} creates a cell predictive Multilock PLSPM Model \code{cplspm}. \cr
#' \code{is.cpmm()} tests if its argument is  \code{cplspm}.\cr
#' @param x :  a \code{cpmm}.
#' @param  procedure  an optional character indicating the name of a plspm procedure to estimate weights. Possible values are 'laplacian' or 'laplacian' or 'hanafi_wold'
#' @param modes  character vector indicating the estimation mode for each block. Possible values are "A" or "B"
#' @param scheme  string with three possible values "centroid" , "factorial" or 'path'.
#' @importFrom "stats"  "sd"
#' @return a  \code{cplspm}.
#' @examples
#' data(cheese)
#' path_matrix <- matrix(c(0, 0, 0,1, 0, 0,1, 1, 0),3,3)
#' blocks=list(chim=4:8,rheo=9:10,senso=11:16)
#' x=cpmm(cheese, blocks, path_matrix)
#' x=cplspm(x)
#' is.cplspm(x)
#' @export cplspm


cplspm <- function(x, procedure='hanafi_wold',modes=NULL, scheme ="factorial"){

  # check
  if(!is.cpmm(x)) stop("\n 'cplspm' x must be a cpmm ")
  if(!((is.character(scheme) | length(scheme)!=1)))     stop("\n'cplspm' scheme must be a string")
  if(!(((scheme=='centroid')|(scheme=='factorial')|(scheme=='path')))) stop("\'cplspm' invalid value for scheme")

  if(is.null(modes)) modes<-rep("A",length(blocking(x)))
  if(!((is.character(modes) & length(modes)==length(blocking(x))))) stop("\n 'cplspm' modes must be an appropriate character vector") # que A ou B
  if(!(all((modes=='B')|(modes=='A')))) stop("\n'modes' possible values of modes are A or B")

  if(!((is.character(procedure) | length(procedure)!=1)))     stop("\n'cplspm' procedure must be a string")
  if(!(((procedure=='lohmoller')|(procedure=='laplacian')|(procedure=='hanafi_wold')))) stop("\'cplspm' invalid name for procedure")
  y=x
  if(is.null(attr(MVs(x),"scaled:center"))) MVs(y)<-scale(MVs(y),scale=FALSE)
  ww<-start(x)
  ww=bvec2diag(ww,blocking(x))
  d=apply(MVs(x)%*%ww,2,'sd')
  dinv=1/d
  dinv[d < .Machine$double.eps]=0
  ww=as.vector(ww%*%diag(dinv)%*%rep(1,length(blocking(x))))
  start(y)<-ww
  w<-weights(y)
  w=bvec2diag(w,blocking(x))
  d=apply(MVs(x)%*%w,2,'sd')
  dinv=1/d
  dinv[d < .Machine$double.eps]=0
  w=as.vector(w%*%diag(dinv)%*%rep(1,length(blocking(x))))
  names(w)<-colnames(MVs(x))
  weights(y)<-w
  names(ww)<-colnames(MVs(x))
  attr(y,"modes") <-modes
  attr(y,"scheme") <-scheme
  attr(y,"procedure") <-procedure
  class(y) =  append(class(y),"cplspm")
  return(y)
}


#' @title Test if its argument is  \code{cplspm}.
#' @description  \code{is.cplspm(x) } tests if its argument is \code{cplspm}.
#' @param x an \code{R} object.
#' @return   a logical value.
#' @keywords internal
#' @export is.cplspm
is.cplspm <- function(x) {
  if(!(!is.null(attr(x, "modes"))& !is.null(attr(x, "procedure"))& !is.null(attr(x, "scheme")))) return(FALSE) else return(TRUE)
}

#' @title Turn a list of \code{cplspm} to a \code{pplspm}
#' @description  \code{c2ppplspm(x) } attenmps to turn Turn a list of \code{cplspm} to a \code{pplspm}
#' @param x a list of  \code{cplspm}.
#' @return   a \code{pplspm}.
#' @keywords internal
#' @export c2pplspm
c2pplspm <- function(x){
  if(is.null(x)|!is.list(x)) stop("\n'as.pplspm.cplspm()' x' must be a list.")
  if(!all(do.call(rbind,lapply(x,class))[,1]=='cpmm')) stop("\n'as.pplspm.cpplspm()' x must be a list of cpmm.")
  if(!all(do.call(rbind,lapply(x,class))[,2]=='cplspm')) stop("\n'as.pplspm.cpplspm()' x must be a list of cplspm")
  if(is.null(names(x))) names=paste('dim', 1:dim) else names=names(x)
  w=lapply(x,weights)
  attr(w, "data") <-lapply(x,MVs)
  attr(w,"names")<-names
  attr(w, "parts") <-blocking(x[[1]])
  attr(w, "path_matrix") <- path.matrix(x[[1]])
  attr(w, "start") <- lapply(x,start)
  attr(w, "tol") <- tol((x[[1]]))
  attr(w, "maxiters") <- maxiters(x[[1]])
  attr(w,"modes") <-modes(x[[1]])
  attr(w,"scheme") <-scheme(x[[1]])
  attr(w,"procedure") <-procedure(x[[1]])
  class(w) =  append('pmm',"pplspm")
  return(w)
}
