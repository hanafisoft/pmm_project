#' @title Lohmoller's iterative procedure for plspm like generalization
#' @description  computes and updates weights for a \code{pplspm} using the plspm like generalization
#' @param x :  a \code{pplspm}
#' @param printin  logical value for printing convergence information.
#' @return a list of \code{cplspm}
#' @examples
#' data(cheese)
#' path_matrix <- matrix(c(0, 0, 0,1, 0, 0,1, 1, 0),3,3)
#' blocks=list(chim=4:8,rheo=9:10,senso=11:16)
#' x=pmm(cheese, blocks, path_matrix,dim=3)
#' x=pplspm(x)
#' xx=g1lohmoller(x,printin=TRUE)
#' lapply(xx,weights)
#' @export g1lohmoller
g1lohmoller  <- function(x,printin){
  UseMethod("g1lohmoller")
}
#' @export
g1lohmoller.default <- function(x,printin)
{
  if (!is.pplspm(x))
    stop("\n'g1lohmoller()' requires a ppslpm .")
}
#' @export
g1lohmoller.pplspm <- function(x, printin=FALSE){
  procedure(x)<-'lohmoller'
  yy=as.cplspm(x)
  if(length(yy)==1){
    yy[[1]]=lohmoller(yy[[1]])
    if(printin)  cat(cat('g1',procedure(yy[[1]])),"=>","dim = ",1, " iter =",attr(yy[[1]],'iter_Obs'),"  accuracy  =", formatC(min(attr(yy[[1]],'error')), format = "e", digits = 0), "\n")
    return(yy)

    }
  else{
    yy[[1]]=lohmoller(yy[[1]])
    if(printin)  cat(cat('g1',procedure(yy[[1]])),"=>","dim = ",1, " iter =",attr(yy[[1]],'iter_Obs'),"  accuracy  =", formatC(min(attr(yy[[1]],'error')), format = "e", digits = 0), "\n")
    for(h in 2:length(yy)){
    MVs(yy[[h]])<-MVs(yy[[h-1]])-MVs(yy[[h-1]])%*%g1coeffs0(yy[[h-1]])
    yy[[h]]=lohmoller(yy[[h]])
    if(printin)  cat(cat('g1',procedure(yy[[h]]),sep="_"),"=>","dim = ",h, " iter =",attr(yy[[h]],'iter_Obs'),"  accuracy  =", formatC(min(attr(yy[[h]],'error')), format = "e", digits = 0), "\n")

    }
    return(yy)
  }
}

#' @title Lohmoller's iterative procedure for plsr like generalization
#' @description  computes and updates weights for a \code{pplspm} using the plsr like generalization
#' @param x :  a \code{pplspm}
#' @param printin  logical value for printing convergence information.
#' @return a list of \code{cplspm}
#' @examples
#' data(cheese)
#' path_matrix <- matrix(c(0, 0, 0,1, 0, 0,1, 1, 0),3,3)
#' blocks=list(chim=4:8,rheo=9:10,senso=11:16)
#' x=pmm(cheese, blocks, path_matrix,dim=3)
#' x=pplspm(x)
#' xx=g2lohmoller(x,printin=TRUE)
#' lapply(xx,weights)
#' @export g2lohmoller
g2lohmoller  <- function(x,printin){
  UseMethod("g2lohmoller")
}
#' @export
g2lohmoller.default <- function(x,printin)
{
  if (!is.pplspm(x))
    stop("\n'g2lohmoller()' requires a ppslpm .")
}
#' @export
g2lohmoller.pplspm <- function(x, printin=FALSE){
  if(!is.logical(printin)|length(printin)!=1)stop("\n'g2lohmoller.pplspm' printin must be logical value .")
  procedure(x)<-'lohmoller'
  yy=as.cplspm(x)
  if(length(yy)==1){
    yy[[1]]=lohmoller(yy[[1]])
    if(printin)  cat(cat('g2',procedure(yy[[1]])),"=>","dim = ",1, " iter =",attr(yy[[1]],'iter_Obs'),"  accuracy  =", formatC(min(attr(yy[[1]],'error')), format = "e", digits = 0), "\n")
    return(yy)

  }
  else{
    yy[[1]]=lohmoller(yy[[1]])
    if(printin)  cat(cat('g2',procedure(yy[[1]])),"=>","dim = ",1, " iter =",attr(yy[[1]],'iter_Obs'),"  accuracy  =", formatC(min(attr(yy[[1]],'error')), format = "e", digits = 0), "\n")
    for(h in 2:length(yy)){
      MVs(yy[[h]])<-MVs(yy[[h-1]])-MVs(yy[[h-1]])%*%g2coeffs0(yy[[h-1]])
      yy[[h]]=lohmoller(yy[[h]])
      if(printin)  cat(cat('g2',procedure(yy[[h]]),sep="_"),"=>","dim = ",h, " iter =",attr(yy[[h]],'iter_Obs'),"  accuracy  =", formatC(min(attr(yy[[h]],'error')), format = "e", digits = 0), "\n")

    }
    return(yy)
  }
}
#' @title Laplacian's iterative procedure for plspm like generalization
#' @description  computes and updates weights for a \code{pplspm} using the plspm like generalization
#' @param x :  a \code{pplspm}
#' @param printin  logical value for printing convergence information.
#' @return a list of \code{cplspm}
#' @examples
#' data(cheese)
#' path_matrix <- matrix(c(0, 0, 0,1, 0, 0,1, 1, 0),3,3)
#' blocks=list(chim=4:8,rheo=9:10,senso=11:16)
#' x=pmm(cheese, blocks, path_matrix,dim=3)
#' x=pplspm(x)
#' xx=g1laplacian(x,printin=TRUE)
#' lapply(xx,weights)
#' @export g1laplacian
g1laplacian  <- function(x,printin){
  UseMethod("g1laplacian")
}
#' @export
g1laplacian.default <- function(x,printin)
{
  if (!is.pplspm(x))
    stop("\n'g1laplacian()' requires a ppslpm .")
}
#' @export
g1laplacian.pplspm <- function(x, printin=FALSE){
  procedure(x)<-'laplacian'
  yy=as.cplspm(x)
  if(length(yy)==1){
    yy[[1]]=laplacian(yy[[1]])
    if(printin)  cat(cat('g1',procedure(yy[[1]])),"=>","dim = ",1, " iter =",attr(yy[[1]],'iter_Obs'),"  accuracy  =", formatC(min(attr(yy[[1]],'error')), format = "e", digits = 0), "\n")
    return(yy)

  }
  else{
    yy[[1]]=laplacian(yy[[1]])
    if(printin)  cat(cat('g1',procedure(yy[[1]])),"=>","dim = ",1, " iter =",attr(yy[[1]],'iter_Obs'),"  accuracy  =", formatC(min(attr(yy[[1]],'error')), format = "e", digits = 0), "\n")
    for(h in 2:length(yy)){
      MVs(yy[[h]])<-MVs(yy[[h-1]])-MVs(yy[[h-1]])%*%g1coeffs0(yy[[h-1]])
      yy[[h]]=laplacian(yy[[h]])
      if(printin)  cat(cat('g1',procedure(yy[[h]]),sep="_"),"=>","dim = ",h, " iter =",attr(yy[[h]],'iter_Obs'),"  accuracy  =", formatC(min(attr(yy[[h]],'error')), format = "e", digits = 0), "\n")

    }
    return(yy)
  }
}

#' @title Laplacian's iterative procedure for plsr like generalization
#' @description  computes and updates weights for a \code{pplspm} using the plsr like generalization
#' @param x :  a \code{pplspm}
#' @param printin  logical value for printing convergence information.
#' @return a list of \code{cplspm}
#' @examples
#' data(cheese)
#' path_matrix <- matrix(c(0, 0, 0,1, 0, 0,1, 1, 0),3,3)
#' blocks=list(chim=4:8,rheo=9:10,senso=11:16)
#' x=pmm(cheese, blocks, path_matrix,dim=3)
#' x=pplspm(x)
#' xx=g2laplacian(x,printin=TRUE)
#' lapply(xx,weights)
#' @export g2laplacian
g2laplacian  <- function(x,printin){
  UseMethod("g2laplacian")
}
#' @export
g2laplacian.default <- function(x,printin)
{
  if (!is.pplspm(x))
    stop("\n'g2laplacian()' requires a ppslpm .")
}
#' @export
g2laplacian.pplspm <- function(x, printin=FALSE){
  if(!is.logical(printin)|length(printin)!=1)stop("\n'g2laplacian.pplspm' printin must be logical value .")
  procedure(x)<-'laplacian'
  yy=as.cplspm(x)
  if(length(yy)==1){
    yy[[1]]=laplacian(yy[[1]])
    if(printin)  cat(cat('g2',procedure(yy[[1]])),"=>","dim = ",1, " iter =",attr(yy[[1]],'iter_Obs'),"  accuracy  =", formatC(min(attr(yy[[1]],'error')), format = "e", digits = 0), "\n")
    return(yy)

  }
  else{
    yy[[1]]=laplacian(yy[[1]])
    if(printin)  cat(cat('g2',procedure(yy[[1]])),"=>","dim = ",1, " iter =",attr(yy[[1]],'iter_Obs'),"  accuracy  =", formatC(min(attr(yy[[1]],'error')), format = "e", digits = 0), "\n")
    for(h in 2:length(yy)){
      MVs(yy[[h]])<-MVs(yy[[h-1]])-MVs(yy[[h-1]])%*%g2coeffs0(yy[[h-1]])
      yy[[h]]=laplacian(yy[[h]])
      if(printin)  cat(cat('g2',procedure(yy[[h]]),sep="_"),"=>","dim = ",h, " iter =",attr(yy[[h]],'iter_Obs'),"  accuracy  =", formatC(min(attr(yy[[h]],'error')), format = "e", digits = 0), "\n")

    }
    return(yy)
  }
}
#' @title Hanafi-Wold's iterative procedure for plspm like generalization
#' @description  computes and updates weights for a \code{pplspm} using the plspm like generalization
#' @param x :  a \code{pplspm}
#' @param printin  logical value for printing convergence information.
#' @return a list of \code{cplspm}
#' @examples
#' data(cheese)
#' path_matrix <- matrix(c(0, 0, 0,1, 0, 0,1, 1, 0),3,3)
#' blocks=list(chim=4:8,rheo=9:10,senso=11:16)
#' x=pmm(cheese, blocks, path_matrix,dim=3)
#' x=pplspm(x)
#' xx=g1hanafi_wold(x,printin=TRUE)
#' lapply(xx,weights)
#' @export g1hanafi_wold
g1hanafi_wold  <- function(x,printin){
  UseMethod("g1hanafi_wold")
}
#' @export
g1hanafi_wold.default <- function(x,printin)
{
  if (!is.pplspm(x))
    stop("\n'g1hanafi_wold()' requires a ppslpm .")
}
#' @export
g1hanafi_wold.pplspm <- function(x, printin=FALSE){
  procedure(x)<-'hanafi_wold'
  yy=as.cplspm(x)
  if(length(yy)==1){
    yy[[1]]=hanafi_wold(yy[[1]])
    if(printin)  cat(cat('g1',procedure(yy[[1]])),"=>","dim = ",1, " iter =",attr(yy[[1]],'iter_Obs'),"  accuracy  =", formatC(min(attr(yy[[1]],'error')), format = "e", digits = 0), "\n")
    return(yy)

  }
  else{
    yy[[1]]=hanafi_wold(yy[[1]])
    if(printin)  cat(cat('g1',procedure(yy[[1]])),"=>","dim = ",1, " iter =",attr(yy[[1]],'iter_Obs'),"  accuracy  =", formatC(min(attr(yy[[1]],'error')), format = "e", digits = 0), "\n")
    for(h in 2:length(yy)){
      MVs(yy[[h]])<-MVs(yy[[h-1]])-MVs(yy[[h-1]])%*%g1coeffs0(yy[[h-1]])
      yy[[h]]=hanafi_wold(yy[[h]])
      if(printin)  cat(cat('g1',procedure(yy[[h]]),sep="_"),"=>","dim = ",h, " iter =",attr(yy[[h]],'iter_Obs'),"  accuracy  =", formatC(min(attr(yy[[h]],'error')), format = "e", digits = 0), "\n")

    }
    return(yy)
  }
}

#' @title Hanafi-Wold's  iterative procedure for plsr like generalization
#' @description  computes and updates weights for a \code{pplspm} using the plsr like generalization
#' @param x :  a \code{pplspm}
#' @param printin  logical value for printing convergence information.
#' @return a list of \code{cplspm}
#' @examples
#' data(cheese)
#' path_matrix <- matrix(c(0, 0, 0,1, 0, 0,1, 1, 0),3,3)
#' blocks=list(chim=4:8,rheo=9:10,senso=11:16)
#' x=pmm(cheese, blocks, path_matrix,dim=3)
#' x=pplspm(x)
#' xx=g2hanafi_wold(x,printin=TRUE)
#' lapply(xx,weights)
#' @export g2hanafi_wold
g2hanafi_wold  <- function(x,printin){
  UseMethod("g2hanafi_wold")
}
#' @export
g2hanafi_wold.default <- function(x,printin)
{
  if (!is.pplspm(x))
    stop("\n'g2hanafi_wold()' requires a ppslpm .")
}
#' @export
g2hanafi_wold.pplspm <- function(x, printin=FALSE){
  if(!is.logical(printin)|length(printin)!=1)stop("\n'g2hanafi_wold.pplspm' printin must be logical value .")
  procedure(x)<-'hanafi_wold'
  yy=as.cplspm(x)
  if(length(yy)==1){
    yy[[1]]=hanafi_wold(yy[[1]])
    if(printin)  cat(cat('g2',procedure(yy[[1]])),"=>","dim = ",1, " iter =",attr(yy[[1]],'iter_Obs'),"  accuracy  =", formatC(min(attr(yy[[1]],'error')), format = "e", digits = 0), "\n")
    return(yy)

  }
  else{
    yy[[1]]=hanafi_wold(yy[[1]])
    if(printin)  cat(cat('g2',procedure(yy[[1]])),"=>","dim = ",1, " iter =",attr(yy[[1]],'iter_Obs'),"  accuracy  =", formatC(min(attr(yy[[1]],'error')), format = "e", digits = 0), "\n")
    for(h in 2:length(yy)){
      MVs(yy[[h]])<-MVs(yy[[h-1]])-MVs(yy[[h-1]])%*%g2coeffs0(yy[[h-1]])
      yy[[h]]=hanafi_wold(yy[[h]])
      if(printin)  cat(cat('g2',procedure(yy[[h]]),sep="_"),"=>","dim = ",h, " iter =",attr(yy[[h]],'iter_Obs'),"  accuracy  =", formatC(min(attr(yy[[h]],'error')), format = "e", digits = 0), "\n")

    }
    return(yy)
  }
}
