
#' @export
g1msepc.pplspm <-function(x,printin){
  # reconstitution of raw data
  if(!is.pplspm(x)) stop("\n'g1msepc ()' requires a pplspm.")
  xdata=MVs(x)[[1]]
  if(is.null(attr(xdata,"scaled:center")))  stop("\n'g1msepc ()' requires a at least a centred manifest variables.")
  if(!is.null(attr(xdata,"scaled:center"))& is.null(attr(xdata,"scaled:scale"))){
    m=as.matrix(rep(1,nrow(xdata)),nrow(xdata),1)%*%t(as.matrix(attr(xdata,"scaled:center")))
    xdata=xdata+m
  }

  if(!is.null(attr(xdata,"scaled:center"))& !is.null(attr(xdata,"scaled:scale"))){
    m=as.matrix(rep(1,nrow(xdata),nrow(xdata),1))%*%t(as.matrix(attr(xdata,"scaled:center")))
    d=attr(xdata,'scaled:scale')
    xdata=xdata%*%diag(d)+m
  }

  # calibration
  xx=switch(procedure(x),lohmoller=g1lohmoller(x,printin),laplacian=g1laplacian(x,printin),hanafi_wold=g1hanafi_wold(x,printin))
  xx0=g1predict(c2pplspm(xx),xdata)
  msepcal=lapply(lapply(xx0$residual,function(x){apply(x,2,function(y){norm(y,'2')^2})}),'*',(1/nrow(xdata)))
   return(msepcal)

}

#' @export
g1loomsep.pplspm <-function(x,printin=TRUE){

 # reconstitution of raw data xdata
    if(!is.pplspm(x)) stop("\n'g1loomsep ()' requires a pplspm.")
    xdata=MVs(x)[[1]]
    if(is.null(attr(xdata,"scaled:center")))  stop("\n'g1loomsep ()' requires a at least a centred manifeste variables.")
    if(!is.null(attr(xdata,"scaled:center"))& is.null(attr(xdata,"scaled:scale"))){
      m=as.matrix(rep(1,nrow(xdata)),nrow(xdata),1)%*%t(as.matrix(attr(xdata,"scaled:center")))
      xdata=xdata+m
      scaled=FALSE
    }

    if(!is.null(attr(xdata,"scaled:center"))& !is.null(attr(xdata,"scaled:scale"))){
      m=as.matrix(rep(1,nrow(xdata),nrow(xdata),1))%*%t(as.matrix(attr(xdata,"scaled:center")))
      d=attr(xdata,'scaled:scale')
      xdata=xdata%*%diag(d)+m
      scaled=TRUE
    }

    n=dim(xdata)[1]
    p=dim(xdata)[2]
    mse=rep(0,p)
    names(mse)<-colnames(xdata)
    mse=rep(list(mse), length(x))
    xx=x
    for (fold in 1 : n){
      if(!scaled) datatest=scale(xdata[-fold,],scale=FALSE)
      if(scaled) datatest=scale(xdata[-fold,],scale=TRUE)
      MVs(xx)<-rep(list(datatest),length(xx))
      xx=pplspm(xx,procedure=procedure(x),modes=modes(x),scheme=scheme(x))# normes des weights
      xx=switch(procedure(xx),lohmoller=g1lohmoller(xx,printin),laplacian=g1laplacian(xx,printin),hanafi_wold=g1hanafi_wold(xx,printin))
      xx=c2pplspm(xx)
      dataval=t(as.matrix(xdata[fold,]))
      xx0=g1predict(xx,dataval)
      dataval=t(as.matrix(xdata[fold,]))
      xx0=g2predict(xx,dataval)

      msepval=lapply(lapply(xx0$residual,function(x){apply(x,2,function(y){norm(y,'2')^2})}),'*',(1/nrow(dataval)))
      if(printin) cat("training data set =",fold,"\n")
      mse=mapply("+", msepval, mse, SIMPLIFY = FALSE)
    }
    mse=lapply(mse,'*',1/n)
    return(mse)
  }

#' @export
g1cvmsep.pplspm <-function(x,kfolds=NULL,nrepeat=NULL,printin=TRUE){

  # reconstitution of raw data xdata
  if(!is.pplspm(x)) stop("\n'g1cvmsep ()' requires a pplspm.")
  xdata=MVs(x)[[1]]
  if(is.null(attr(xdata,"scaled:center")))  stop("\n'g1cvmsep ()' requires a at least a centred manifeste variables.")
  if(!is.null(attr(xdata,"scaled:center"))& is.null(attr(xdata,"scaled:scale"))){
    m=as.matrix(rep(1,nrow(xdata)),nrow(xdata),1)%*%t(as.matrix(attr(xdata,"scaled:center")))
    xdata=xdata+m
    scaled=FALSE
  }

  if(!is.null(attr(xdata,"scaled:center"))& !is.null(attr(xdata,"scaled:scale"))){
    m=as.matrix(rep(1,nrow(xdata),nrow(xdata),1))%*%t(as.matrix(attr(xdata,"scaled:center")))
    d=attr(xdata,'scaled:scale')
    xdata=xdata%*%diag(d)+m
    scaled=TRUE
  }
  if(is.null(kfolds)) kfolds=as.integer(sqrt(nrow(xdata)))# compromise variance and biais
  if(!(as.integer(kfolds)==kfolds & kfolds>0 & (length(kfolds)==1) & kfolds<dim(MVs(x)[[1]])[1])) stop("\n'g1plspm ()' kfolds must be a positive integer")
  if(is.null(nrepeat)) nrepeat=1
  if(!(as.integer(nrepeat)==nrepeat & nrepeat>0 & (length(nrepeat)==1))) stop("\n'g1plspm ()' kfolds must be a positive integer")
  n=dim(xdata)[1]
  p=dim(xdata)[2]

  mse=rep(0,p)
  names(mse)<-colnames(xdata)
  mse=rep(list(mse), length(x))
  xx=x
  for (r in 1:nrepeat) {
    rowsidx  <- sapply(1:kfolds,function(i) {list(which(cut(sample(1:n,replace=FALSE),breaks=kfolds,labels=FALSE)==i))})
    for (fold in 1 : kfolds){
      if(!scaled) datatest=scale(xdata[-rowsidx[[fold ]],],scale=FALSE)
      if(scaled) datatest=scale(xdata[-rowsidx[[fold ]],],scale=TRUE)
      MVs(xx)<-rep(list(datatest),length(x))
      xx=pplspm(xx,procedure=procedure(x),modes=modes(x),scheme=scheme(x))# normes des weights
      xx=switch(procedure(xx),lohmoller=g1lohmoller(xx),laplacian=g1laplacian(xx),hanafi_wold=g1hanafi_wold(xx))
      xx=c2pplspm(xx)
      dataval=xdata[rowsidx[[fold ]],]
      #msepval
      xx0=g1predict(xx,dataval)
      msepval=lapply(lapply(xx0$residual,function(x){apply(x,2,function(y){norm(y,'2')^2})}),'*',(1/nrow(dataval)))
      mse=mapply("+", msepval, mse, SIMPLIFY = FALSE)
      if(printin) cat("repetition =",r,"segment =",fold, "\n")
    }

  }
  mse=lapply(mse,'*',(1/(kfolds*nrepeat)))
  return(mse)
}



#' @export
g2msepc.pplspm <-function(x,printin){

    # reconstitution of raw data
    if(!is.pplspm(x)) stop("\n'g2msepc ()' requires a pplspm.")
    xdata=MVs(x)[[1]]
    if(is.null(attr(xdata,"scaled:center")))  stop("\n'g2msepc ()' requires a at least a centred manifest variables.")
    if(!is.null(attr(xdata,"scaled:center"))& is.null(attr(xdata,"scaled:scale"))){
      m=as.matrix(rep(1,nrow(xdata)),nrow(xdata),1)%*%t(as.matrix(attr(xdata,"scaled:center")))
      xdata=xdata+m
    }

    if(!is.null(attr(xdata,"scaled:center"))& !is.null(attr(xdata,"scaled:scale"))){
      m=as.matrix(rep(1,nrow(xdata),nrow(xdata),1))%*%t(as.matrix(attr(xdata,"scaled:center")))
      d=attr(xdata,'scaled:scale')
      xdata=xdata%*%diag(d)+m
    }

    # calibration
    xx=switch(procedure(x),lohmoller=g2lohmoller(x,printin),laplacian=g2laplacian(x,printin),hanafi_wold=g2hanafi_wold(x,printin))
    xx0=g2predict(c2pplspm(xx),xdata)
    msepcal=lapply(lapply(xx0$residual,function(x){apply(x,2,function(y){norm(y,'2')^2})}),'*',(1/nrow(xdata)))
    return(msepcal)

}

#' @export
g2loomsep.pplspm <-function(x,printin=TRUE){

  # reconstitution of raw data xdata
  if(!is.pplspm(x)) stop("\n'g2loomsep ()' requires a pplspm.")
  xdata=MVs(x)[[1]]
  if(is.null(attr(xdata,"scaled:center")))  stop("\n'g2loomsep ()' requires a at least a centred manifeste variables.")
  if(!is.null(attr(xdata,"scaled:center"))& is.null(attr(xdata,"scaled:scale"))){
    m=as.matrix(rep(1,nrow(xdata)),nrow(xdata),1)%*%t(as.matrix(attr(xdata,"scaled:center")))
    xdata=xdata+m
    scaled=FALSE
  }

  if(!is.null(attr(xdata,"scaled:center"))& !is.null(attr(xdata,"scaled:scale"))){
    m=as.matrix(rep(1,nrow(xdata),nrow(xdata),1))%*%t(as.matrix(attr(xdata,"scaled:center")))
    d=attr(xdata,'scaled:scale')
    xdata=xdata%*%diag(d)+m
    scaled=TRUE
  }
colnames(xdata)<-colnames(MVs(x)[[1]])
  n=dim(xdata)[1]
  p=dim(xdata)[2]
  mse=rep(0,p)
  names(mse)<-colnames(xdata)
  mse=rep(list(mse), length(x))
  xx=x
  for (fold in 1 : n){
    if(!scaled) datatest=scale(xdata[-fold,],scale=FALSE)
    if(scaled) datatest=scale(xdata[-fold,],scale=TRUE)
    MVs(xx)<-rep(list(datatest),length(xx))
    xx=pplspm(xx,procedure=procedure(x),modes=modes(x),scheme=scheme(x))# normes des weights
    xx=switch(procedure(xx),lohmoller=g2lohmoller(xx,printin),laplacian=g2laplacian(xx,printin),hanafi_wold=g2hanafi_wold(xx,printin))
    xx=c2pplspm(xx)
    dataval=t(as.matrix(xdata[fold,]))
    xx0=g2predict(xx,dataval)

    msepval=lapply(lapply(xx0$residual,function(x){apply(x,2,function(y){norm(y,'2')^2})}),'*',(1/nrow(dataval)))
    if(printin) cat("training data set =",fold,"\n")
    mse=mapply("+", msepval, mse, SIMPLIFY = FALSE)
  }
  mse=lapply(mse,'*',1/n)
  return(mse)
}

################################################"

#' @export
g2cvmsep.pplspm <-function(x,kfolds=NULL,nrepeat=NULL,printin=TRUE){

  # reconstitution of raw data xdata
  if(!is.pplspm(x)) stop("\n'g2cvmsep ()' requires a pplspm.")
  xdata=MVs(x)[[1]]
  if(is.null(attr(xdata,"scaled:center")))  stop("\n'g1cvmsep ()' requires a at least a centred manifeste variables.")
  if(!is.null(attr(xdata,"scaled:center"))& is.null(attr(xdata,"scaled:scale"))){
    m=as.matrix(rep(1,nrow(xdata)),nrow(xdata),1)%*%t(as.matrix(attr(xdata,"scaled:center")))
    xdata=xdata+m
    scaled=FALSE
  }

  if(!is.null(attr(xdata,"scaled:center"))& !is.null(attr(xdata,"scaled:scale"))){
    m=as.matrix(rep(1,nrow(xdata),nrow(xdata),1))%*%t(as.matrix(attr(xdata,"scaled:center")))
    d=attr(xdata,'scaled:scale')
    xdata=xdata%*%diag(d)+m
    scaled=TRUE
  }
  if(is.null(kfolds)) kfolds=as.integer(sqrt(nrow(xdata)))# compromise variance and biais
  if(!(as.integer(kfolds)==kfolds & kfolds>0 & (length(kfolds)==1) & kfolds<dim(MVs(x)[[1]])[1])) stop("\n'g1plspm ()' kfolds must be a positive integer")
  if(is.null(nrepeat)) nrepeat=1
  if(!(as.integer(nrepeat)==nrepeat & nrepeat>0 & (length(nrepeat)==1))) stop("\n'g1plspm ()' kfolds must be a positive integer")
  n=dim(xdata)[1]
  p=dim(xdata)[2]

  mse=rep(0,p)
  names(mse)<-colnames(xdata)
  mse=rep(list(mse), length(x))
  xx=x
  for (r in 1:nrepeat) {
    rowsidx  <- sapply(1:kfolds,function(i) {list(which(cut(sample(1:n,replace=FALSE),breaks=kfolds,labels=FALSE)==i))})
    for (fold in 1 : kfolds){
      if(!scaled) datatest=scale(xdata[-rowsidx[[fold ]],],scale=FALSE)
      if(scaled) datatest=scale(xdata[-rowsidx[[fold ]],],scale=TRUE)
      MVs(xx)<-rep(list(datatest),length(x))
      xx=pplspm(xx,procedure=procedure(x),modes=modes(x),scheme=scheme(x))# normes des weights
      xx=switch(procedure(xx),lohmoller=g1lohmoller(xx),laplacian=g1laplacian(xx),hanafi_wold=g1hanafi_wold(xx))
      xx=c2pplspm(xx)
      dataval=xdata[rowsidx[[fold ]],]
      #msepval
      xx0=g1predict(xx,dataval)
      msepval=lapply(lapply(xx0$residual,function(x){apply(x,2,function(y){norm(y,'2')^2})}),'*',(1/nrow(dataval)))
      mse=mapply("+", msepval, mse, SIMPLIFY = FALSE)
      if(printin) cat("repetition =",r,"segment =",fold, "\n")
    }

  }
  mse=lapply(mse,'*',(1/(kfolds*nrepeat)))
  return(mse)
}
