#' @export
g1coeffs.pmm <-function(x)
{
  ls=lapply(as.cpmm(x),g1coeffs)
  p=dim(MVs(x)[[1]])[2]
  for (h in 2:length(x)){
      ls[[h]]=ls[[h-1]]+(diag(p)-ls[[h-1]])%*%ls[[h]]# B(<=H)=B(<=H-1)+(I-B(<=H-1))B(H)
  }
    return(ls)
  }

#' @export
g2coeffs.pmm <-function(x)
{
  ls=lapply(as.cpmm(x),g2coeffs)
  p=dim(MVs(x)[[1]])[2]
  for (h in 2:length(x)){
    ls[[h]]=ls[[h-1]]+(diag(p)-ls[[h-1]])%*%ls[[h]]# B(<=H)=B(<=H-1)+(I-B(<=H-1))B(H)
  }
  return(ls)
}
#' @export
g1intercept.pmm <-function(x){
  ls=g1coeffs(x)
  m1=t(as.matrix(attr(MVs(x)[[1]],"scaled:center")))
  res=vector('list',length(x))
  for (h in 1:length(x)){
      res[[h]]=m1-m1%*%ls[[h]]
  }
  names(res)<-names(x)
  return(res)
}
#' @export
g2intercept.pmm <-function(x){
  ls=g2coeffs(x)
  m2=t(as.matrix(attr(MVs(x)[[1]],"scaled:center")))
  res=vector('list',length(x))
  for (h in 1:length(x)){
    res[[h]]=m2-m2%*%ls[[h]]
  }
  names(res)<-names(x)
  return(res)
}
#' @export
g1predict.pmm <-function(x,y){

  if (!is.matrix(y)) stop("\n 'g1predict.pmm' requires response data as matrix ")
  if ((!is.numeric(y)|dim(y)[2]!=dim(MVs(x)[[1]])[2])) stop("\n  not appropriate dimension of the response data .")
  l1=vector('list',length(x))
  l2=vector('list',length(x))
  m1=g1intercept(x)
  g1=g1coeffs(x)
  for (h in 1:length(x)){
      xx0=as.matrix(rep(1,nrow(y)))%*%(as.matrix(m1[[h]]))-as.matrix(rep(1,nrow(y)))%*%(as.matrix(m1[[h]]))%*%g1[[h]]+y%*%g1[[h]]
      l1[[h]]=xx0
      l2[[h]]=y-xx0
  }
  names(l1)<-names(x)
  names(l2)<-names(x)
  l=list(predicted=l1,residuals=l2)
  return(l)
}
#' @export
g2predict.pmm <-function(x,y){

  if (!is.matrix(y)) stop("\n 'g2predict.pmm' requires response data as matrix ")
  if ((!is.numeric(y)|dim(y)[2]!=dim(MVs(x)[[1]])[2])) stop("\n  not appropriate dimension of the response data .")
  l1=vector('list',length(x))
  l2=vector('list',length(x))
  m2=g1intercept(x)
  g2=g1coeffs(x)
  for (h in 1:length(x)){
    xx0=as.matrix(rep(1,nrow(y)))%*%(as.matrix(m2[[h]]))-as.matrix(rep(1,nrow(y)))%*%(as.matrix(m2[[h]]))%*%g2[[h]]+y%*%g2[[h]]
    l1[[h]]=xx0
    l2[[h]]=y-xx0
  }
  names(l1)<-names(x)
  names(l2)<-names(x)
  l=list(predicted=l1,residuals=l2)
  return(l)
}

