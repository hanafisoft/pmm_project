#' @export
loadings.pmm <- function(x)
{
  return(lapply(as.cpmm(x),loadings))
}

#' @export
path.coeffs.pmm <- function(x)
{
  return(lapply(as.cpmm(x),path.coeffs))
}


#' @export
lvs.pmm <- function(x)
{
  return(lapply(as.cpmm(x),lvs))
}




