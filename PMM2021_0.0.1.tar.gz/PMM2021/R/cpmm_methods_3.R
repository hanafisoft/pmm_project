#' @title  Unstandardized Regression coefficients for PLSPM like generalization.
#' @description This function allows to recover unstandardized regression coefficients of a \code{cpmm} or a \code{pmm} .
#' @param x a \code{cpmm} or a \code{pmm} .
#' @return Returns  an upper block triangular matrix for \code{cpmm} or a list of  upper block triangular matrices for a \code{pmm}
#' @export g1coeffs

g1coeffs <- function(x){
  UseMethod("g1coeffs", x)
}
#' @export
g1coeffs.default <- function(x)
{
  if (!is.cpmm(x)|!is.pmm(x))
    stop("\n'g1coeffs' requires a cpmm or pmm .")
}

#' @export
g1coeffs.cpmm <-function(x)
{
    xx=MVs(x)
    l=attributes(xx)
    if(!is.null(attributes(xx)[["scaled:center"]]) & is.null(attributes(xx)[["scaled:scale"]])){
      B = g1coeffs0(x)
      return(B)
    }
    if(!is.null(attributes(xx)[["scaled:center"]]) & !is.null(attributes(xx)[["scaled:scale"]])){
      B = g1coeffss(x)
      return(B)
    }
    else{
      stop("\n'g1coeffs' manifest variables must be only centred or centred and scaled ")

    }

  }
#' @title  Unstandardized Regression coefficients for PLSR like generalization
#' @description This function allows to recover unstandardized regression coefficients of a \code{cpmm} or a \code{pmm} .
#' @param x a \code{cpmm} or a \code{pmm} .
#' @return Returns  an upper block triangular matrix for \code{cpmm} or list of  upper block triangular matrices for a \code{pmm}
#' @export g2coeffs

g2coeffs <- function(x){
  UseMethod("g2coeffs", x)
}
#' @export
g2coeffs.default <- function(x)
{
  if (!is.cpmm(x)|!is.pmm(x))
    stop("\n'g2coeffs' requires a cpmm or pmm .")
}

#' @export
g2coeffs.cpmm <-function(x)
{

  xx=MVs(x)
  l=attributes(xx)
  if(!is.null(attributes(xx)[["scaled:center"]]) & is.null(attributes(xx)[["scaled:scale"]])){
    B = g2coeffs0(x)
    return(B)
  }
  if(!is.null(attributes(xx)[["scaled:center"]]) & !is.null(attributes(xx)[["scaled:scale"]])){
    B = g2coeffss(x)
  return(B)
  }
  else{
    stop("\n'g2coeffs' manifest variables must be only centred or centred and scaled ")

  }

}

#' @title Intercept term for PLSPM like generalization.
#' @description \code{g1intercept} gets  the intercept term
#' @param x a \code{cpmm} or a \code{pmm} .
#' @return Returns the constant term as a matrix for \code{cpmm} or as list of matrices for \code{pmm}.
#' @export g1intercept

g1intercept <- function(x){
  UseMethod("g1intercept", x)
}
#' @export
g1intercept.default <- function(x)
{
  if (!is.cpmm(x)|!is.pmm(x))
    stop("\n'g1intercept()' requires a cpmm or pmm .")
}
#' @export
g1intercept.cpmm <-function(x){
  res=t(as.matrix(attr(MVs(x),"scaled:center")))-t(as.matrix(attr(MVs(x),"scaled:center")))%*%g1coeffs(x)
  return(res)
}
#' @title Intercept term for PLSPR like generalization.
#' @description \code{g2intercept} gets  the intercept term
#' @param x a \code{cpmm} or a \code{pmm} .
#' @return Returns the constant term as a matrix for \code{cpmm} or as list of matrices for \code{pmm}.
#' @export g2intercept
#' @aliases g2intercept

g2intercept <- function(x){
  UseMethod("g2intercept", x)
}
#' @export
g2intercept.default <- function(x)
{
  if (!is.cpmm(x)|!is.pmm(x))
    stop("\n'g2intercept()' requires a cpmm or pmm .")
}
#' @export
g2intercept.cpmm <-function(x){
  res=t(as.matrix(attr(MVs(x),"scaled:center")))-t(as.matrix(attr(MVs(x),"scaled:center")))%*%g2coeffs(x)
  return(res)
}



#' @title  Standardized Regression coefficients for centred or scaled manifest variables (PLSPM like generalization).
#' @description This function allows to recover regression coefficients of a \code{cpmm} or a \code{pmm} .
#' @param x a \code{cpmm} or a \code{pmm} .
#' @return Returns  an upper block triangular matrix for \code{cpmm} or a list of  upper block triangular matrices for a \code{pmm}
#' @export g1coeffs0
g1coeffs0 <- function(x){
  UseMethod("g1coeffs0", x)
}
#' @export
g1coeffs0.default <- function(x)
{
  if (!is.cpmm(x)|!is.pmm(x))
    stop("\n'g1coeffs0' requires a cpmm or pmm .")
}

#' @export
g1coeffs0.cpmm <-function(x)
{
  xx=MVs(x)
  if(is.null(attributes(xx)[["scaled:center"]])) stop("\n'g1coeffs0' manifest variables must be centred")
  IDM=path.matrix(x)
  endo = colSums(IDM)
  endo[endo!=0] <- 1  # vector indicating endogenous LVs
  exog <- colSums(IDM)==0
  B <- path.coeffs(x)
  diag(B)[exog]<-1
  B=bvec2diag(weights(x),blocking(x))%*%B%*%t(bvec2diag(loadings(x),blocking(x)))
  rownames(B)=colnames(MVs(x))
  colnames(B)=colnames(MVs(x))
  return(B)
}

#' @title  Standardized Regression coefficients for centred manifeste variables (PLS like generalization).
#' @description This function allows to recover regression coefficients of an \code{cpmm} or a \code{pmm}.
#' @param x a \code{cpmm} or a \code{pmm} .
#' @return Returns  an upper block triangular matrix.
#' @importFrom "MASS"  "ginv"
#' @export g2coeffs0


g2coeffs0  <- function(x){
  UseMethod("g2coeffs0", x)
}
#' @export
g2coeffs0.default <- function(x)
{
  if (!is.cpmm(x)|!is.pmm(x))
    stop("\n' g2coeffs0()' requires a cpmm or pmm .")
}
#' @export
g2coeffs0.cpmm <-function(x){
  data=MVs(x)
  if(is.null(attributes(data)[["scaled:center"]])) stop("\n'g2coeffs0' manifest variables must be centred")
  IDM=path.matrix(x)
  parts=blocking(x)
  data=MVs(x)
  p=dim(data)[2]
  # exoversus endo
  exog <- colSums(IDM)==0 # exo LV
  lvs1=lvs(x)
  i1=0
  i2=0
  B=matrix(0,length(parts),sum(parts))
  for (aux in 1:nrow(IDM))
  {
    i1=i1+1
    i2=i2+parts[aux]
    if(exog[aux]){
      B[aux,i1:i2]<-loadings(x)[i1:i2]
    }else{
      c <- which(path.matrix(x)[1:aux,aux]==1)
      B[c,i1:i2] <- ginv(t(lvs1[,c])%*%lvs1[,c])%*%t(lvs1[,c])%*%data[,i1:i2]
    }
    i1=i2
  }
  B=bvec2diag(weights(x),parts)%*%B
  rownames(B)=colnames(data)
  colnames(B)=colnames(data)
  return(B)
}


#' @title  Unstandardized Regression coefficients for scaled manifest variables (PLSPM like generalization)
#' @description This function allows to recover regression coefficients of a \code{cpmm} or a \code{pmm} .
#' @param x a \code{cpmm} or a \code{pmm} .
#' @return Returns  an upper block triangular matrix for \code{cpmm} or a list of  upper block triangular matrices for a \code{pmm}
#' @keywords internal
#' @export g1coeffss


g1coeffss <- function(x){
  UseMethod("g1coeffss", x)
}
#' @export
g1coeffss.default <- function(x)
{
  if (!is.cpmm(x)|!is.pmm(x))
    stop("\n'g1coeffss' requires a cpmm or pmm .")
}

#' @export
g1coeffss.cpmm <-function(x)
{
  xx=MVs(x)
  if(((is.null(attributes(xx)[["scaled:center"]]) & is.null(attributes(xx)[["scaled:scales"]])))) stop("\n'g1coeffss' manifest variables must be centred")
  B=g1coeffs0(x)
  l=attributes(xx)
  d=l$`scaled:scale`
  dinv=1/d
  dinv[d < .Machine$double.eps]=0
  B=diag(dinv)%*%B%*%diag(d)
  rownames(B)=colnames(MVs(x))
  colnames(B)=colnames(MVs(x))
  return(B)
}

#' @title   Unstandardized Regression coefficients for scalaed manifest variables (PLS like generalization)
#' @description This function allows to recover regression coefficients of an \code{cpmm} or a \code{pmm}.
#' @param x a \code{cpmm} or a \code{pmm} .
#' @return Returns  an upper block triangular matrix.
#' @importFrom "MASS"  "ginv"
#' @keywords internal
#' @export g2coeffss


g2coeffss  <- function(x){
  UseMethod("g2coeffss", x)
}
#' @export
g2coeffss.default <- function(x)
{
  if (!is.cpmm(x)|!is.pmm(x))
    stop("\n' g2coeffss()' requires a cpmm or pmm .")
}
#' @export
g2coeffss.cpmm <-function(x){
  xx=MVs(x)
  if(((is.null(attributes(xx)[["scaled:center"]]) & is.null(attributes(xx)[["scaled:scales"]])))) stop("\n'g1coeffss' manifest variables must be centred")
  B=g2coeffs0(x)
  l=attributes(xx)
  d=l$`scaled:scale`
  dinv=1/d
  dinv[d < .Machine$double.eps]=0
  B=diag(dinv)%*%B%*%diag(d)
  rownames(B)=colnames(MVs(x))
  colnames(B)=colnames(MVs(x))
  return(B)
}
##########################
#' @title Predictive Decomposition for PLSPM like generalization
#' @description This function allows to recover the prediction decomposition of data for a \code{cpmm} or  \code{pmm}
#' @param x a \code{cpmm} or  \code{pmm} .
#' @param y a \code{matrix} to be predicted by x.
#' @return Returns a  list of two matrices for a \code{cpmm} or  \code{pmm}  .
#' @export g1predict
#' @aliases g1predict

g1predict <- function(x,y){
  UseMethod("g1predict", x)
}
#' @export
g1predict.default <- function(x,y)
{
  if (!is.cpmm(x)|!is.pmm(x)) stop("\n'g1predict ()' requires an cpmm or pmm .")
  if (!is.matrix(y)) stop("\n  requires response data as matrix ")
  if (is.cpmm(x)) p=dim(MVs(x))[2]else p=dim(MVs(x)[[1]])[2]
  if ((!is.numeric(y)|dim(y)[2]!=p)) stop("\n  not appropriate dimension of the response data .")


}

#' @export
g1predict.cpmm <-function(x,y){

  xx0=as.matrix(rep(1,nrow(y)))%*%(as.matrix(g1intercept(x)))-as.matrix(rep(1,nrow(y)))%*%(as.matrix(g1intercept(x)))%*%g1coeffs(x)+y%*%g1coeffs(x)
  l=list(predicted=xx0,residual=y-xx0)
  return(l)
}
################
#' @title Predictive Decomposition for  PLSR like generalization.
#' @description This function allows to recover the prediction decomposition of data for a \code{cpmm} or  \code{pmm}
#' @param x a \code{cpmm} or  \code{pmm} .
#' @param y a \code{matrix} to be predicted by x.
#' @return Returns a  list of two matrices for a \code{cpmm} or each cell of \code{pmm}  .
#' @export g2predict

g2predict <- function(x,y){
  UseMethod("g2predict", x)
}
#' @export
g2predict.default <- function(x,y)
{
  if (!is.cpmm(x)|!is.pmm(x)) stop("\n'g1predict ()' requires an cpmm or pmm .")
  if (!is.matrix(y)) stop("\n  requires response data as matrix ")
  if (is.cpmm(x)) p=dim(MVs(x))[2]else p=dim(MVs(x)[[1]])[2]
  if ((!is.numeric(y)|dim(y)[2]!=p)) stop("\n  not appropriate dimension of the response data .")

}
#' @export
g2predict.cpmm <-function(x,y){
  xx0=as.matrix(rep(1,nrow(y)))%*%(as.matrix(g2intercept(x)))-as.matrix(rep(1,nrow(y)))%*%(as.matrix(g2intercept(x)))%*%g2coeffs(x)+y%*%g2coeffs(x)
  l=list(predicted=xx0,residual=y-xx0)
  return(l)
}
