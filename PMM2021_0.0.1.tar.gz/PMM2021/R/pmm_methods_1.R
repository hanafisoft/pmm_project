
#' @title Upper bound of the mean squares Frobenius norm of the twi succesive iterations
#' @description
#' \code{tol} allows to recover the upper bound  of the mean squares Frobenius norm of  the error for a \code{pmm} or  \code{cpmm}.
#' @details
#' Use \code{tol<-value} to update upper bound  of the mean squares Frobenius norm of  the error for a \code{pmm} or  \code{cpmm}. \cr
#' @param x a \code{pmm} or  \code{cpmm}.
#' @return Returns a numeric  value.
#' @export tol
tol  <- function(x){
  UseMethod("tol", x)
}
#' @export
tol.default <- function(x)
{
  if (!is.pmm(x) |!is.cpmm(x))
    stop("\n'tol()' requires a pmm or cpmm")
}
#' @export
tol.pmm <- function(x)
{
  return(attr(x,"tol"))
}
tol  <- function(x){
  UseMethod("tol", x)
}
#' @export
tol.default <- function(x)
{
  if (!is.pmm(x))
    stop("\n'tol()' requires a pmm ")
}
#' @export
tol.pmm <- function(x)
{
  return(attr(x,"tol"))
}

#' @title Upper bound of the mean squares Frobenius norm of the two succesive iterations for \code{pmm} or \code{cpmm}
#' @description update the mean squares Frobenius norm of  the error for   \code{pmm} or \code{cpmm}.
#' @param x a  \code{pmm} or \code{cpmm}
#' @param value a numeric value
#' @return  a  \code{pmm} or \code{cpmm}
#' @export "tol<-"
"tol<-" <-  function(x,value) {
  UseMethod("tol<-")
}

#' @export
"tol<-.default" <- function(x,value)
{
  if (!is.pmm(x)) stop("\n tol<-() requires a pmm or pplspm.")
}
#' @export
"tol<-.pmm"<- function(x,value)
{
  if (!is.numeric(value)) stop("\n tol<-() requires an integer ")
  if (!(length(value)==1))  stop("\n tol<-() requires an numeric value")
  attr(x, "tol") <-value
  return(x)
}
#' @title Upper bound of iterations
#' @description
#' \code{maxiters} allows to recover the upper bound of iterations of a \code{pmm} or \code{cpmm}.
#' @details
#' Use \code{maxiters<-value} to update the upper bound of iterations .
#' @param x a \code{pmm}.
#' @return Returns  a \code{pmm} or \code{cpmm}.
#' @export maxiters

maxiters  <- function(x){
  UseMethod("maxiters", x)
}
#' @export
maxiters.default <- function(x)
{
  if (!is.pmm(x)) stop("\n'maxiters()' requires a pmm or pmm.")
}
#' @export
maxiters.pmm <- function(x)
{
  return(attr(x, "maxiters"))
}
#' @title Update upper bound ofiterations
#' @description
#' \code{"maxiters<-" } allows to recover the upper bound  upper bound ofiterations  \code{pmm}.
#' @param x a \code{pmm}
#' @param value a numeric value
#' @return  a \code{pmm}
#' @export "maxiters<-"


"maxiters<-" <-  function(x,value) {
  UseMethod("maxiters<-")
}
#' @export
"maxiters<-.default" <- function(x,value)
{
  if (!is.pmm(x)) stop("\n maxiters<-() requires a pmm model.")
  if (!is.numeric(value)) stop("\n maxiters<-() requires an integer ")
  if (!(length(value)==1))  stop("\n maxiters<-()requires an integer value")

}
#' @export
"maxiters<-.pmm"<- function(x,value)
{

  attr(x, "maxiters") <-value
  return(x)
}
#' @export
MVs.pmm <- function(x)
{
  return(attr(x,"data"))
}

#' @export
"MVs<-.pmm"<- function(x,value)
{
  if (!is.list(value)) stop("\n MVs<-() requires a list of  matrices of MVs ")
  if ( !all(do.call(rbind,lapply(value,is.numeric)))) stop("\n MVs<-() :   requires a list of numeric matrices of MVs ")
  if ( !all(do.call(rbind,lapply(value,function(x){dim(x)[2]}))==do.call(rbind,lapply(MVs(x),function(x){dim(x)[2]}))))stop("\n MVs<-() :  invalid dimension")

  attr(x, "data") <-value
  return(x)
}
#' @export
weights.pmm <- function(x)
{
  xx=x
  attributes(xx)<-NULL
  names(xx)<-attr(x,'names')
  return(xx)
}
#' @export
"weights<-.pmm" <- function(x,value)
{
  if (!is.list(value)) stop("\n weights<-() requires a list of  vectors ")
  if ( !all(do.call(rbind,lapply(value,is.numeric)))) stop("\n weights=<-() :   requires a list of numeric vectors ")
  if ( !all(do.call(rbind,lapply(value,length))==do.call(rbind,lapply(weights(x),length))))stop("\n weights=<- :   invalid length ")
  ss<-attributes(x)
  x<-value
  attributes(x)<-ss
  return(x)
}

#' @export
start.pmm <- function(x)
{
  return(attr(x,"start"))
}
#' @export
"start<-.pmm"<- function(x,value)
{

  if (!is.list(value)) stop("\n start<-() requires a list of  vectors ")
  if ( !all(do.call(rbind,lapply(value,is.numeric)))) stop("\n start<-() :   requires a list of numeric vectors  ")
  if ( !all(do.call(rbind,lapply(value,length))==do.call(rbind,lapply(start(x),length))))stop("\n start<-() :   invalid length ")
  attr(x,"start")<-value
  return(x)
}

#' @export
blocking.pmm <- function(x)
{
  return(attr(x,'parts'))
}
#' @export
"blocking<-.pmm" <- function(x,value)
{
  if (!is.vector(value)) stop("\n blocking<-() requires value as vector  ")
  if (!is.numeric(value)) stop("\n blocking<-() :  value must be integer vector.")
  if (! (length(value)==length(blocking(x)) & sum(value)==sum(blocking(x)))) stop("\n blocking<-() :  invalid length .")

  names(value)<-names(blocking(x))
  attr(x, "parts") <-value
  return(x)
  return(attr(x,'parts'))
}

#' @export
path.matrix.pmm <- function(x)
{
  return(attr(x,'path_matrix'))
}

#' @export
"path.matrix<-.pmm"<- function(x,value)
{
  if (!is.matrix(value)) stop("\n path.matrix<-() requires a matrix  ")
  if (!(is.numeric(value) & (dim(value)[1]=dim(value)[2]))) stop("\n path.matrix<-() :  requires  a square matrix.")
  if (dim(value)[1]!=dim(path.matrix(x))[1]) stop("\n path.matrix<-() :  invalid dimension .")
  M=value
  M[lower.tri(M,diag=TRUE)] <-0
  if(!(all(M==value))) stop("\n path.matrix<-() : requires upper triangular matrix with diagonal=0.")
  if(!all((M==1)|(M==0)))stop("\n path.matrix<-() :' requires a binary matrix  .")

  rownames(value)<-rownames(path.matrix(x))
  colnames(value)<-colnames(path.matrix(x))
  attr(x, "path_matrix") <-value
  return(x)
}
#' @export
length.pmm<- function(x)
{
  return(length(attr(x,'names')))
}
#' @export
"[.pmm"<- function(x,i)
{
  if(is.null(i)) {
    return(x)
  }
  if(!(is.numeric(i) & all(1:i %in% (1:length(x))))) stop("\n 'length' must be a positive integer low than dim(x) ")
  y=x
  attributes(y)<-NULL
  y=y[1:i]
  attr(y,'data')<-MVs(x)[1:i]
  attr(y,'start')<-start(x)[1:i]
  attr(y,"names")<- attr(x,'names')[1:i]
  attr(y,"parts")<- blocking(x)
  attr(y,"path_matrix")<- path.matrix(x)
  attr(y,"tol")<tol(x)
  attr(y,"maxiters")<-  maxiters(x)
  class(y)<-class(x)
  return(y)
}
#' @export
names.pmm<- function(x)
{
  return(attr(x,'names'))
}
#' @export
names.pmm<- function(x)
{
  return(attr(x,'names'))
}

#' @export
"names<-.pmm"<- function(x,value)
{
  if(!is.character(value))stop("\n 'names<-' value must be a character vector")
  if(length(names(x))!=length(value)) stop("\n 'names<-' invalid length for value")
  attr(x,"names")<-value
  return(x)
}
#' @export
"[[.pmm"<- function(x,i)
{
  if(is.null(i)|i>=length(x)) return(x)
  return(as.cpmm(x)[[i]])
}

