#' @title Mean Squared Error of Calibration (MSEC) for PLSPM like generalization.
#' @description This function allows to recover the MSEC a \code{cpmm} or a \code{pmm}
#' @param x a \code{cpmm}.
#' @param printin  logical value for printing convergence information.
#' @return Returns a \code{vector}
#' @export g1msepc
g1msepc <- function(x,printin){
  UseMethod("g1msepc", x)
}
#' @export
g1msepc.default <- function(x,printin)
{
  if (!is.cpmm(x)|!is.pmm(x)) stop("\n'g1msepc ()' requires a cpmm or pmm .")

}
#' @export
g1msepc.cplspm <-function(x,printin){

  # reconstitution of raw data
  if(!is.cplspm(x)) stop("\n'g1msepc ()' requires a cplspm.")
  xdata=MVs(x)
  if(is.null(attr(xdata,"scaled:center")))  stop("\n'g1msepc ()' requires a at least a centred manifest variables.")
  if(!is.null(attr(xdata,"scaled:center"))& is.null(attr(xdata,"scaled:scale"))){
    m=as.matrix(rep(1,nrow(xdata)),nrow(xdata),1)%*%t(as.matrix(attr(xdata,"scaled:center")))
    xdata=xdata+m
  }

  if(!is.null(attr(xdata,"scaled:center"))& !is.null(attr(xdata,"scaled:scale"))){
    m=as.matrix(rep(1,nrow(xdata),nrow(xdata),1))%*%t(as.matrix(attr(xdata,"scaled:center")))
    d=attr(xdata,'scaled:scale')
    xdata=xdata%*%diag(d)+m
  }

  # calibration
  xx=switch(procedure(x),lohmoller=lohmoller(x,printin),laplacian=laplacian(x,printin),hanafi_wold=hanafi_wold(x,printin))
  xx0=g1predict(x,xdata)
  msepcal=as.vector((1/nrow(xdata))*as.matrix(apply(xx0$residual,2,function(y){norm(y,'2')^2})))
  names(msepcal)<-colnames(m)
  return(msepcal)
}

################################################"
#' @title Cross Validation Mean Squared error of Predicton (MSEP) for PLSPM like generalization.
#' @description This function allows to recover the MSEC a \code{cpmm} or a \code{pmm}
#' @param x a \code{cpmm} or  \code{pmm}.
#' @param kfolds an \code{integer} the number of segments.
#' @param nrepeat an \code{integer} the number of repetitions.
#' @param printin  logical value for printing convergence information.
#' @return Returns a  \code{vector}
#' @export g1cvmsep
g1cvmsep <- function(x,kfolds,nrepeat,printin){
  UseMethod("g1cvmsep")
}
#' @export
g1cvmsep.default <- function(x,kfolds,nrepeat,printin)
{
  if (!is.cpmm(x)|!is.pmm(x)) stop("\n'g1cvmsep ()' requires a cpmm or pmm .")
  if (!(is.integer(kfolds)| kfolds==0)) stop("\n'g1cvmsep ()' requires a positive integer kfolds ")
  if (!(is.integer(nrepeat)| nrepeat==0)) stop("\n'g1cvmsep ()' requires a positive integer nrepeat ")

}
#' @export
g1cvmsep.cplspm <-function(x,kfolds=NULL,nrepeat=NULL,printin=TRUE){

  # reconstitution of raw data xdata
  if(!is.cplspm(x)) stop("\n'g1cvmsep ()' requires a cplspm.")
  xdata=MVs(x)
  if(is.null(attr(xdata,"scaled:center")))  stop("\n'g1cvmsep ()' requires a at least a centred manifeste variables.")
  if(!is.null(attr(xdata,"scaled:center"))& is.null(attr(xdata,"scaled:scale"))){
    m=as.matrix(rep(1,nrow(xdata)),nrow(xdata),1)%*%t(as.matrix(attr(xdata,"scaled:center")))
    xdata=xdata+m
    scaled=FALSE
  }

  if(!is.null(attr(xdata,"scaled:center"))& !is.null(attr(xdata,"scaled:scale"))){
    m=as.matrix(rep(1,nrow(xdata),nrow(xdata),1))%*%t(as.matrix(attr(xdata,"scaled:center")))
    d=attr(xdata,'scaled:scale')
    xdata=xdata%*%diag(d)+m
    scaled=TRUE
  }
  if(is.null(kfolds)) kfolds=as.integer(sqrt(nrow(xdata)))# compromise variance and biais
  if(!(as.integer(kfolds)==kfolds & kfolds>0 & (length(kfolds)==1) & kfolds<dim(MVs(x))[1])) stop("\n'g1plspm ()' kfolds must be a positive integer")
  if(is.null(nrepeat)) nrepeat=1
  if(!(as.integer(nrepeat)==nrepeat & nrepeat>0 & (length(nrepeat)==1))) stop("\n'g1plspm ()' kfolds must be a positive integer")
  n=dim(xdata)[1]
  p=dim(xdata)[2]
  mse=rep(0,p)
  xx=x
  for (r in 1:nrepeat) {
    rowsidx  <- sapply(1:kfolds,function(i) {list(which(cut(sample(1:n,replace=FALSE),breaks=kfolds,labels=FALSE)==i))})
    for (fold in 1 : kfolds){
      if(!scaled) datatest=scale(xdata[-rowsidx[[fold ]],],scale=FALSE)
      if(scaled) datatest=scale(xdata[-rowsidx[[fold ]],],scale=TRUE)
      MVs(xx)<-datatest
      xx=cplspm(xx,procedure=procedure(x),modes=modes(x),scheme=scheme(x))# normes des weights
      xx=switch(procedure(xx),lohmoller=lohmoller(xx),laplacian=laplacian(xx),hanafi_wold=hanafi_wold(xx))
      dataval=xdata[rowsidx[[fold ]],]
      #msepval
      xx0=g1predict(xx,dataval)
      msepval=as.vector((1/nrow(dataval))*as.matrix(apply(xx0$residual,2,function(y){norm(y,'2')^2})))
      if(printin) cat("repetition =",r,"segment =",fold," msepval =", formatC(sum(msepval), format = "e", digits = 0),"\n")
      mse=mse+msepval
    }

  }
  mse=(1/(kfolds*nrepeat))*mse
  names(mse)<-colnames(m)
  return(mse)
}


#' @title Leave One Out Mean Squared error of Predicton (MSEP) for PLSPM like generalization..
#' @description This function performs leave one out procedure for a \code{cpmm}.
#' @param x a \code{cpmm} or  \code{pmm}
#' @param printin  logical value for printing convergence information.
#' @return Returns a  \code{vector}
#' @export g1loomsep
g1loomsep <- function(x,printin){
  UseMethod("g1loomsep")
}
#' @export
g1loomsep.default <- function(x,printin)
{
  if (!is.cpmm(x)|!is.pmm(x)) stop("\n'g1loomsep ()' requires a cpmm or pmm .")

}
#' @export
g1loomsep.cplspm <-function(x,printin=TRUE){

  # reconstitution of raw data xdata
  if(!is.cplspm(x)) stop("\n'g1loomsep ()' requires a cplspm.")
  xdata=MVs(x)
  if(is.null(attr(xdata,"scaled:center")))  stop("\n'g1loomsep ()' requires a at least a centred manifeste variables.")
  if(!is.null(attr(xdata,"scaled:center"))& is.null(attr(xdata,"scaled:scale"))){
    m=as.matrix(rep(1,nrow(xdata)),nrow(xdata),1)%*%t(as.matrix(attr(xdata,"scaled:center")))
    xdata=xdata+m
    scaled=FALSE
  }

  if(!is.null(attr(xdata,"scaled:center"))& !is.null(attr(xdata,"scaled:scale"))){
    m=as.matrix(rep(1,nrow(xdata),nrow(xdata),1))%*%t(as.matrix(attr(xdata,"scaled:center")))
    d=attr(xdata,'scaled:scale')
    xdata=xdata%*%diag(d)+m
    scaled=TRUE
  }

  n=dim(xdata)[1]
  p=dim(xdata)[2]
  mse=rep(0,p)
  xx=x
  for (fold in 1 : n){
    if(!scaled) datatest=scale(xdata[-fold,],scale=FALSE)
    if(scaled) datatest=scale(xdata[-fold,],scale=TRUE)
    MVs(xx)<-datatest
    xx=cplspm(xx,procedure=procedure(x),modes=modes(x),scheme=scheme(x))# normes des weights
    xx=switch(procedure(xx),lohmoller=lohmoller(xx,printin),laplacian=laplacian(xx,printin),hanafi_wold=hanafi_wold(xx,printin))
    dataval=t(as.matrix(xdata[fold,]))
    xx0=g1predict(xx,dataval)
    msepval=(1/nrow(dataval))*as.matrix(apply(xx0$residual,2,function(y){norm(y,'2')^2}))
    if(printin){
      s=sum(as.vector(msepval))
      cat("training data set =",fold,"  msepval =", formatC(s, format = "e", digits = 0),"\n")
    }
    mse=mse+msepval
  }
  mse=((1/n)*as.vector(mse))
  names(mse)<-colnames(m)
  return(mse)
}


###########
#' @title Mean Squared Error of Calibration (MSEC) for PLSPR like generalization.
#' @description This function allows to recover the MSEC a \code{cpmm} or a \code{pmm}
#' @param x a \code{cpmm}.
#' @param printin  logical value for printing convergence information.
#' @return Returns a \code{vector}
#' @export g2msepc
g2msepc <- function(x,printin){
  UseMethod("g2msepc", x)
}
#' @export
g2msepc.default <- function(x,printin)
{
  if (!is.cpmm(x)|!is.pmm(x)) stop("\n'g2msepc ()' requires a cpmm or pmm .")

}
#' @export
g2msepc.cplspm <-function(x,printin){

  # reconstitution of raw data
  if(!is.cplspm(x)) stop("\n'g2msepc ()' requires a cplspm.")
  xdata=MVs(x)
  if(is.null(attr(xdata,"scaled:center")))  stop("\n'g2msepc ()' requires a at least a centred manifest variables.")
  if(!is.null(attr(xdata,"scaled:center"))& is.null(attr(xdata,"scaled:scale"))){
    m=as.matrix(rep(1,nrow(xdata)),nrow(xdata),1)%*%t(as.matrix(attr(xdata,"scaled:center")))
    xdata=xdata+m
  }

  if(!is.null(attr(xdata,"scaled:center"))& !is.null(attr(xdata,"scaled:scale"))){
    m=as.matrix(rep(1,nrow(xdata),nrow(xdata),1))%*%t(as.matrix(attr(xdata,"scaled:center")))
    d=attr(xdata,'scaled:scale')
    xdata=xdata%*%diag(d)+m
  }

  # calibration
  xx=switch(procedure(x),lohmoller=lohmoller(x,printin),laplacian=laplacian(x,printin),hanafi_wold=hanafi_wold(x,printin))
  xx0=g1predict(x,xdata)
  msepcal=as.vector((1/nrow(xdata))*as.matrix(apply(xx0$residual,2,function(y){norm(y,'2')^2})))
  names(msepcal)<-colnames(m)
  return(msepcal)
}

################################################"
#' @title Cross Validation Mean Squared error of Predicton (MSEP) for PLSPR like generalization.
#' @description This function allows to recover the MSEC a \code{cpmm} or a \code{pmm}
#' @param x a \code{cpmm} or  \code{pmm}.
#' @param kfolds an \code{integer} the number of segments.
#' @param nrepeat an \code{integer} the number of repetitions.
#' @param printin  logical value for printing convergence information.
#' @return Returns a  \code{vector}
#' @export g2cvmsep
g2cvmsep <- function(x,kfolds,nrepeat,printin){
  UseMethod("g2cvmsep")
}
#' @export
g2cvmsep.default <- function(x,kfolds,nrepeat,printin)
{
  if (!is.cpmm(x)|!is.pmm(x)) stop("\n'g2cvmsep ()' requires a cpmm or pmm .")
  if (!(is.integer(kfolds)| kfolds==0)) stop("\n'g2cvmsep ()' requires a positive integer kfolds ")
  if (!(is.integer(nrepeat)| nrepeat==0)) stop("\n'g2cvmsep ()' requires a positive integer nrepeat ")

}
#' @export
g2cvmsep.cplspm <-function(x,kfolds=NULL,nrepeat=NULL,printin=TRUE){

  # reconstitution of raw data xdata
  if(!is.cplspm(x)) stop("\n'g2plspm ()' requires a cplspm.")
  xdata=MVs(x)
  if(is.null(attr(xdata,"scaled:center")))  stop("\n'g2plspm ()' requires a at least a centred manifeste variables.")
  if(!is.null(attr(xdata,"scaled:center"))& is.null(attr(xdata,"scaled:scale"))){
    m=as.matrix(rep(1,nrow(xdata)),nrow(xdata),1)%*%t(as.matrix(attr(xdata,"scaled:center")))
    xdata=xdata+m
    scaled=FALSE
  }

  if(!is.null(attr(xdata,"scaled:center"))& !is.null(attr(xdata,"scaled:scale"))){
    m=as.matrix(rep(1,nrow(xdata),nrow(xdata),1))%*%t(as.matrix(attr(xdata,"scaled:center")))
    d=attr(xdata,'scaled:scale')
    xdata=xdata%*%diag(d)+m
    scaled=TRUE
  }
  if(is.null(kfolds)) kfolds=as.integer(sqrt(nrow(xdata)))# compromise variance and biais
  if(!(as.integer(kfolds)==kfolds & kfolds>0 & (length(kfolds)==1) & kfolds<dim(MVs(x))[1])) stop("\n'g2plspm ()' kfolds must be a positive integer")
  if(is.null(nrepeat)) nrepeat=1
  if(!(as.integer(nrepeat)==nrepeat & nrepeat>0 & (length(nrepeat)==1))) stop("\n'g2plspm ()' kfolds must be a positive integer")
  n=dim(xdata)[1]
  p=dim(xdata)[2]
  mse=rep(0,p)
  xx=x
  for (r in 1:nrepeat) {
    rowsidx  <- sapply(1:kfolds,function(i) {list(which(cut(sample(1:n,replace=FALSE),breaks=kfolds,labels=FALSE)==i))})
    for (fold in 1 : kfolds){
      if(!scaled) datatest=scale(xdata[-rowsidx[[fold ]],],scale=FALSE)
      if(scaled) datatest=scale(xdata[-rowsidx[[fold ]],],scale=TRUE)
      MVs(xx)<-datatest
      xx=cplspm(xx,procedure=procedure(x),modes=modes(x),scheme=scheme(x))# normes des weights
      xx=switch(procedure(xx),lohmoller=lohmoller(xx),laplacian=laplacian(xx),hanafi_wold=hanafi_wold(xx))
      dataval=xdata[rowsidx[[fold ]],]
      #msepval
      xx0=g2predict(xx,dataval)
      msepval=as.vector((1/nrow(dataval))*as.matrix(apply(xx0$residual,2,function(y){norm(y,'2')^2})))
      if(printin) cat("repetition =",r,"segment =",fold," msepval =", formatC(sum(msepval), format = "e", digits = 0),"\n")
      mse=mse+msepval
    }

  }
  mse=(1/(kfolds*nrepeat))*mse
  names(mse)<-colnames(m)
  return(mse)
}


#' @title Leave One Out Mean Squared error of Predicton (MSEP) for PLSPM like generalization..
#' @description This function performs leave one out procedure for a \code{cpmm}.
#' @param x a \code{cpmm} or  \code{pmm}
#' @param printin  logical value for printing convergence information.
#' @return Returns a  \code{vector}
#' @export g2loomsep
g2loomsep <- function(x,printin){
  UseMethod("g2loomsep")
}
#' @export
g2loomsep.default <- function(x,printin)
{
  if (!is.cpmm(x)|!is.pmm(x)) stop("\n'g2loomsep ()' requires a cpmm or pmm .")

}
#' @export
g2loomsep.cplspm <-function(x,printin=TRUE){

  # reconstitution of raw data xdata
  if(!is.cplspm(x)) stop("\n'g2loomsep ()' requires a cplspm.")
  xdata=MVs(x)
  if(is.null(attr(xdata,"scaled:center")))  stop("\n'g2loomsep ()' requires a at least a centred manifeste variables.")
  if(!is.null(attr(xdata,"scaled:center"))& is.null(attr(xdata,"scaled:scale"))){
    m=as.matrix(rep(1,nrow(xdata)),nrow(xdata),1)%*%t(as.matrix(attr(xdata,"scaled:center")))
    xdata=xdata+m
    scaled=FALSE
  }

  if(!is.null(attr(xdata,"scaled:center"))& !is.null(attr(xdata,"scaled:scale"))){
    m=as.matrix(rep(1,nrow(xdata),nrow(xdata),1))%*%t(as.matrix(attr(xdata,"scaled:center")))
    d=attr(xdata,'scaled:scale')
    xdata=xdata%*%diag(d)+m
    scaled=TRUE
  }

  n=dim(xdata)[1]
  p=dim(xdata)[2]
  mse=rep(0,p)
  xx=x
  for (fold in 1 : n){
    if(!scaled) datatest=scale(xdata[-fold,],scale=FALSE)
    if(scaled) datatest=scale(xdata[-fold,],scale=TRUE)
    MVs(xx)<-datatest
    xx=cplspm(xx,procedure=procedure(x),modes=modes(x),scheme=scheme(x))# normes des weights
    xx=switch(procedure(xx),lohmoller=lohmoller(xx,printin),laplacian=laplacian(xx,printin),hanafi_wold=hanafi_wold(xx,printin))
    dataval=t(as.matrix(xdata[fold,]))
    xx0=g1predict(xx,dataval)
    msepval=(1/nrow(dataval))*as.matrix(apply(xx0$residual,2,function(y){norm(y,'2')^2}))
    if(printin){
      s=sum(as.vector(msepval))
      cat("training data set =",fold,"  msepval =", formatC(s, format = "e", digits = 0),"\n")
    }
    mse=mse+msepval
  }
  mse=(1/n)*as.vector(mse)
  names(mse)<-colnames(m)
  return(mse)
}




