#' @title Cell Predictive Multiblock Model.
#' @description \code{cpmm} creates a cell Predictive Multiblock Model. \cr
#' \code{is.cpmm(x)} tests if its argument is  \code{cpmm}.\cr
#' @param data  matrix or  data frame containing  manifest quantitative variables.
#' @param blocks  list of integer vectors indicating the sets of manifest variables forming each block.
#' @param path_matrix  an adjacency matrix of an oriented graph.Also called path matrix.
#' @param scaled  optionnal logical value. Default value data is scaled, otherwise data is only centred.
#' @param w   numeric vector of  weights.
#' @param start a starting numeric vector of  weights.
#' @param tol  upper bound of the expected mean squares Frobenius norm of the error.
#' @param maxiters upper bound of the expected number of iterations.
#' @return   a \code{cpmm} object.
#' @importFrom "stats"  "runif"
#' @export cpmm
#' @examples
#' data(cheese)
#' path_matrix <- matrix(c(0, 0, 0,1, 0, 0,1, 1, 0),3,3)
#' blocks=list(chim=4:8,rheo=9:10,senso=11:16)
#' x=cpmm(cheese, blocks, path_matrix)

cpmm  <- function(data, blocks=NULL, path_matrix=NULL,scaled =TRUE, w=NULL,start=NULL,tol=1e-05,maxiters=50)
{

  #checking
  if(is.null(data)|!(is.matrix(data)|is.data.frame(data)))
    stop("\n'data' must be a matrix or data frame.")

  if(is.null(blocks) | !is.list(blocks)) stop("\n'blocks' must be a list  .")
  if(!all(unlist(lapply(blocks,is.integer)))) stop("\n'blocks' must a list of integer vectors .")

  if(max(unlist(lapply(blocks,max)))>dim(data)[2])
    stop("\n'blocks' : components of blocks must be less than or equal the number of columns of data.")

  if(is.null(path_matrix)| !(is.matrix(path_matrix)|all(dim(path_matrix)==c(length(blocks),length(blocks)))))
    stop("\n' path_matrix' invalid dimension.")
  M=path_matrix
  M[lower.tri(M,diag=TRUE)] <-0
  if(!(all(M==path_matrix))) stop("\n'path matrix' must be lower triangular with diagonal=0.")
  if(!all((M==1)|(M==0)))stop("\n'path matrix' possible values are only 0 or 1 .")

  rownames(path_matrix)<-names(blocks)
  colnames(path_matrix)<-names(blocks)

  x=as.matrix(data[,unlist(blocks)])
  if(is.null(rownames(x))) rownames(x)<-paste('row',1:dim(x)[1])
  if(is.null(colnames(x))) colnames(x)<-paste('col',1:dim(x)[1])

  if(!all(unlist(lapply(x, is.numeric)))) stop("\n 'data' manifest variables must be numeric.")
  parts = unlist(lapply(blocks, length))
  names(parts)<-rownames(path_matrix)
  if(is.null(w)) w<-runif(dim(x)[2])
  if(!(!is.null(w) & is.numeric(w) & (length(w)==dim(x)[2]))) stop("\n'w'  must be a numeric with compatible dimension or length with data ")
  if(is.null(start)) start<-runif(dim(x)[2])
  if(!(!is.null(start) & is.numeric(start) & (length(start)==dim(x)[2]))) stop("\n'start'  must be a numeric with compatible dimension or length with data ")
  if(!(as.integer(maxiters)==maxiters & length(maxiters)==1))     stop("\n'pmm' maxiters' must be an integer value")
  if(!(is.numeric(tol) & length(tol)==1 & tol>=0)) stop("\n'pmm' tol must be a positive numeric value")
  names(w)<-colnames(x)
  names(start)<-colnames(x)

  if(scaled) x<-scale(x) else x<-scale(x,scale=FALSE)

  attr(w, "data") <-x
  attr(w, "start") <- start
  attr(w, "parts") <-parts
  attr(w, "path_matrix") <- path_matrix
  attr(w, "tol") <- tol
  attr(w, "maxiters") <- maxiters
  class(w) <-'cpmm'
  return(w)
}

#' @title Test if its argument is  \code{cpmm}.
#' @description  \code{is.cpmm(x) } tests if its argument is \code{cpmm}.
#' @param x an \code{R} object.
#' @return   a logical value.
#' @keywords internal
#' @export is.cpmm
is.cpmm<- function(x) {
return(all(c("data","parts","path_matrix","start","tol","maxiters") %in%names(attributes(x))))
}

#' @title Turn a list of \code{cpmm} to a \code{pmm}
#' @description  \code{c2pmm()} attenmps to turn Turn a list of \code{cpmm} to a \code{pmm}
#' @param x a list of  \code{cpmm}.
#' @return   a \code{pmm}.
#' @keywords internal
#' @export c2pmm
c2pmm <- function(x){
  if(is.null(x)|!is.list(x)) stop("\n'as.pmm.cpmm()' requieres  a list.")
  if(!all(do.call(rbind,lapply(x,class))=='cpmm')) stop("\n'as.pmm.cpmm()' requieres  a list of cpmm.")
  #checking
  if(is.null(names(x))) names(x)<-paste('dim', 1:dim)
  w=lapply(x,weights)
  attr(w, "data") <-lapply(x,MVs)
  attr(w,"names")<-names(x)
  attr(w, "parts") <-blocking(x[[1]])
  attr(w, "path_matrix") <- path.matrix(x[[1]])
  attr(w, "start") <- lapply(x,start)
  attr(w, "tol") <- tol((x[[1]]))
  attr(w, "maxiters") <- maxiters(x[[1]])
  class(w) = "pmm"
  return(w)
}
